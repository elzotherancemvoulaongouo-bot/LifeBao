
const PEOPLE = [
  {init:'AD',color:'#1D9E75',name:'Amina Diallo',handle:'@amina.bao',followers:'4.8k',online:true,following:false},
  {init:'KM',color:'#185FA5',name:'Kweku Mensah',handle:'@kweku.bao',followers:'3.1k',online:true,following:false},
  {init:'FS',color:'#993556',name:'Fatou Sow',handle:'@fatou.bao',followers:'6.2k',online:false,following:true},
  {init:'SN',color:'#854F0B',name:'Serge Nkurunziza',handle:'@serge.bao',followers:'2.4k',online:false,following:false},
  {init:'LB',color:'#534AB7',name:'Léa Bourgeois',handle:'@lea.bao',followers:'1.9k',online:true,following:false},
];

let filPosts = [
  {id:1,user:PEOPLE[0],time:'2 min',text:'Le coucher de soleil sur la colline Rebero ce soir… 😍 #KigaliVibe',emoji:'🌅',likes:124,comments:18,liked:false},
  {id:2,user:PEOPLE[1],time:'15 min',text:'Mon jollof rice est officiellement le meilleur du continent 🤌🔥 #AfrikaFood',emoji:'🍛',likes:312,comments:54,liked:true},
  {id:3,user:PEOPLE[2],time:'1 h',text:'Life Bao connecte les âmes africaines à travers le monde 🌍💚 #LifeBao',emoji:'🌍',likes:88,comments:11,liked:false},
];

// Comments data: postId -> array of comments
const COMMENTS_DATA = {
  1:[
    {id:101,user:PEOPLE[1],text:'Vraiment magnifique ! Kigali au coucher de soleil, rien de mieux 🌅',time:'1 min',likes:8,liked:false,replies:[
      {id:1011,user:PEOPLE[2],text:'Totalement d\'accord avec toi Kweku ! 💚',time:'à l\'instant',likes:2,liked:false},
    ]},
    {id:102,user:PEOPLE[3],text:'On devrait organiser une sortie photo là-bas 📸',time:'1 min',likes:5,liked:true,replies:[]},
    {id:103,user:PEOPLE[4],text:'Quelle beauté 😍😍😍',time:'2 min',likes:3,liked:false,replies:[]},
  ],
  2:[
    {id:201,user:PEOPLE[0],text:'HAHA bold claim 😂 Tu nous invites à goûter ?',time:'5 min',likes:22,liked:false,replies:[
      {id:2011,user:PEOPLE[1],text:'Venez samedi chez moi ! 🍛🔥',time:'4 min',likes:11,liked:false},
    ]},
    {id:202,user:PEOPLE[2],text:'Le jollof sénégalais reste le roi 👑 (on en parle ?)',time:'10 min',likes:14,liked:false,replies:[]},
    {id:203,user:PEOPLE[3],text:'J\'arrive avec la sauce piment 🌶️',time:'12 min',likes:7,liked:true,replies:[]},
    {id:204,user:PEOPLE[4],text:'Je partage tout de suite à ma famille 😄',time:'14 min',likes:4,liked:false,replies:[]},
  ],
  3:[
    {id:301,user:PEOPLE[1],text:'Tellement fier.e d\'être bao 💚🌍',time:'30 min',likes:12,liked:true,replies:[]},
    {id:302,user:PEOPLE[3],text:'Life Bao c\'est notre maison numérique ✨',time:'45 min',likes:9,liked:false,replies:[]},
  ],
};

// Reactions per post
const REACTIONS_DATA = {
  1:{emojis:{'❤️':47,'🔥':12,'😍':31,'🌅':8,'👏':5}},
  2:{emojis:{'🔥':89,'😂':34,'🍛':56,'❤️':41,'👏':22}},
  3:{emojis:{'💚':28,'🌍':19,'❤️':15,'✨':11,'👏':7}},
};
const userReactions={}; // postId -> emoji or null
const openComments=new Set(); // set of open post ids
let replyingTo=null; // {postId, commentId, name}

let notifs = [
  {id:1,type:'like',user:PEOPLE[0],text:'a aimé ta photo',emoji:'❤️',thumb:'🌅',time:'2 min',unread:true,group:"Aujourd'hui"},
  {id:2,type:'follow',user:PEOPLE[1],text:"s'est abonné·e à toi",emoji:'👤',thumb:null,time:'10 min',unread:true,group:"Aujourd'hui",actions:true},
  {id:3,type:'comment',user:PEOPLE[2],text:'a commenté : <b>"Magnifique 🌺"</b>',emoji:'💬',thumb:'🌍',time:'30 min',unread:true,group:"Aujourd'hui"},
  {id:4,type:'mention',user:PEOPLE[3],text:"t'a mentionné dans un post",emoji:'🏷️',thumb:'📸',time:'1 h',unread:true,group:"Aujourd'hui"},
  {id:5,type:'live',user:PEOPLE[4],text:'est en live maintenant',emoji:'🔴',thumb:null,time:'1 h',unread:true,group:"Aujourd'hui",live:true},
  {id:6,type:'like',user:PEOPLE[1],text:'et <b>12 autres</b> ont aimé ta photo',emoji:'❤️',thumb:'🌺',time:'hier',unread:false,group:'Hier'},
  {id:7,type:'comment',user:PEOPLE[0],text:'a répondu à ton commentaire',emoji:'💬',thumb:'🌅',time:'hier',unread:false,group:'Hier'},
];

const CONVOS = [
  {id:0,user:PEOPLE[0],prev:"Le coucher de soleil 😍",time:'2 min',unread:2},
  {id:1,user:PEOPLE[1],prev:"Mon jollof est prêt 🍛",time:'15 min',unread:0},
  {id:2,user:PEOPLE[2],prev:"Life Bao c'est trop bien !",time:'1 h',unread:1},
  {id:3,user:PEOPLE[3],prev:"Tu viens au match ce soir?",time:'3 h',unread:0},
];

const THREADS = {
  0:[{me:false,text:"Salut ! Tu as vu mon post ce soir ? 🌅"},{me:true,text:"Oui, magnifique ! Kigali est incroyable 😍"},{me:false,text:"On organise une sortie photo ?"}],
  1:[{me:false,text:"Bro, mon jollof c'est le meilleur 🤌"},{me:true,text:"Tu m'invites à goûter ?"},{me:false,text:"Viens samedi ! 🍛"}],
  2:[{me:false,text:"Life Bao c'est notre espace ❤️"},{me:true,text:"Fier.e d'être bao 🌍"}],
  3:[{me:false,text:"Tu viens au match ce soir ?"},{me:true,text:"Quel match ?"},{me:false,text:"Stade Amahoro, 19h 🔥"}],
};

const EXP_GRIDS = {
  tout:       ['🌅','🍛','🦁','🌸','🌍','🎞️'],
  photos:     ['📸','🎞️','🌅','🌸','🏙️','🌺'],
  videos:     ['🎬','🎥','📹','🎭','🎤','📺'],
  live:       ['🔴','📡','🎙️','📺','🎤','🎬'],
  evenements: ['🎉','🎊','🎈','🎆','🥳','🏆'],
  food:       ['🍛','🥘','🍜','🥗','🍲','🥭'],
  art:        ['🎨','🖼️','✏️','🎭','🖌️','🏺'],
};
const EXP_COLORS = ['#dff3eb','#faeeda','#fbeaf0','#eeedfe','#E1F5EE','#faeeda'];

const SEARCH_INDEX = [
  ...PEOPLE.map(p=>({type:'person',...p,sub:`${p.handle} · ${p.followers} abonnés`})),
  {type:'tag',name:'#KigaliVibe',sub:'24.3k posts'},
  {type:'tag',name:'#AfrikaFood',sub:'18.1k posts'},
  {type:'tag',name:'#LifeBao',sub:'51.7k posts'},
  {type:'tag',name:'#SunsetAfrica',sub:'9.8k posts'},
  {type:'event',name:'Kigali Photo Walk',sub:'14 Juin · Kigali'},
  {type:'event',name:'AfrikaFood Festival',sub:'21 Juin · Dakar'},
];

let nextId=200, activeChat=null, activeNotifTab='tous', activePubType='photo', pubHasMedia=false, activeExpCat='tout';

const SCREEN_ORDER = ['fil','explorer','pub','live','profil','parametres','dashboard','communaute','messages','notifs','page-detail','groupe-detail','live-room'];
let prevScreen = 'fil';

function getSlideDir(from, to) {
  const fi = SCREEN_ORDER.indexOf(from);
  const ti = SCREEN_ORDER.indexOf(to);
  if(fi===-1||ti===-1) return 'fade';
  return ti>fi ? 'right' : 'left';
}

function goScreen(name) {
  const current = document.querySelector('.screen.active');
  const next = document.getElementById('screen-'+name);
  if(!next||current===next) return;
  const dir = getSlideDir(prevScreen, name);
  if(current) {
    current.classList.add(dir==='right'?'slide-out-left':dir==='left'?'slide-out-right':'fade-in');
    setTimeout(()=>current.classList.remove('active','slide-out-left','slide-out-right','fade-in'), 280);
  }
  next.style.display='block';
  const inClass = dir==='right'?'slide-in-right':dir==='left'?'slide-in-left':(name==='parametres'||name==='dashboard')?'scale-in':'fade-in';
  next.classList.add(inClass,'active');
  setTimeout(()=>{ next.classList.remove('slide-in-right','slide-in-left','scale-in','fade-in'); applyReveal(next); }, 350);
  prevScreen = name;
  document.querySelectorAll('.bn').forEach(b=>b.classList.remove('active'));
  const map={fil:'bn-fil',explorer:'bn-explorer',pub:'bn-pub',live:'bn-live',profil:'bn-profil'};
  if(map[name]){ const bnEl=document.getElementById(map[name]); bnEl.classList.add('active'); slideNavIndicator(bnEl); }
  if(name==='notifs'){markAllRead();hideBadges();}
  if(name==='messages'){closeChat();}
  if(name==='explorer'){renderExpContent(activeExpCat);}
  if(name==='profil'){renderProfGrid();animateProfileStats();}
  if(name==='parametres'){closeSubPanel();}
  if(name==='communaute'){renderCommunaute();}
  if(name==='live'){renderLiveList();}
  if(name==='dashboard'){renderDashboard();}
}

function applyReveal(container) {
  const items = container.querySelectorAll('.post-card,.kpi-card,.com-card,.live-entry-card,.event-card,.chart-wrap,.tip-card,.top-post-item');
  items.forEach((el,i)=>{ el.classList.add('reveal'); setTimeout(()=>el.classList.add('visible'), i*55); });
}

function slideNavIndicator(activeBtn) {
  let ind = document.getElementById('bn-indicator');
  if(!ind){ ind=document.createElement('div'); ind.id='bn-indicator'; ind.className='bn-indicator'; const nav=document.querySelector('.bottom-nav'); nav.style.position='relative'; nav.appendChild(ind); }
  const nav=document.querySelector('.bottom-nav');
  const nr=nav.getBoundingClientRect(), br=activeBtn.getBoundingClientRect();
  ind.style.left=(br.left-nr.left+10)+'px'; ind.style.width=(br.width-20)+'px';
}

function triggerLikeBurst(btn) {
  const rect=btn.getBoundingClientRect(), sr=document.querySelector('.shell').getBoundingClientRect();
  const b=document.createElement('div'); b.className='like-burst'; b.textContent='❤️';
  b.style.left=(rect.left-sr.left+rect.width/2-14)+'px'; b.style.top=(rect.top-sr.top+rect.height/2-14)+'px';
  document.querySelector('.shell').appendChild(b); setTimeout(()=>b.remove(),700);
}

function triggerReactionBurst(btn,emoji) {
  const rect=btn.getBoundingClientRect(), sr=document.querySelector('.shell').getBoundingClientRect();
  const b=document.createElement('div'); b.className='reaction-burst'; b.textContent=emoji;
  b.style.left=(rect.left-sr.left+rect.width/2-10)+'px'; b.style.top=(rect.top-sr.top-5)+'px';
  document.querySelector('.shell').appendChild(b); setTimeout(()=>b.remove(),600);
}

function addRipple(el,e) {
  const rect=el.getBoundingClientRect(), size=Math.max(rect.width,rect.height)*1.5;
  const x=(e.clientX||rect.left+rect.width/2)-rect.left-size/2;
  const y=(e.clientY||rect.top+rect.height/2)-rect.top-size/2;
  const r=document.createElement('div'); r.className='ripple';
  r.style.cssText=`width:${size}px;height:${size}px;left:${x}px;top:${y}px;`;
  el.classList.add('ripple-host'); el.appendChild(r); setTimeout(()=>r.remove(),550);
}
document.addEventListener('click',e=>{
  const t=e.target.closest('.auth-submit,.com-btn-p,.lec-join-btn,.ev-btn,.pub-submit,.step-next-btn,.live-send-btn');
  if(t) addRipple(t,e);
});

const CONFETTI_COLORS=['#1D9E75','#FAC775','#D85A30','#185FA5','#534AB7','#993556'];
function launchConfetti(count=40) {
  for(let i=0;i<count;i++){
    const p=document.createElement('div'); p.className='confetti-piece';
    p.style.cssText=`left:${5+Math.random()*90}vw;background:${CONFETTI_COLORS[Math.floor(Math.random()*CONFETTI_COLORS.length)]};--dur:${1.5+Math.random()*1.5}s;--delay:${Math.random()*.6}s;width:${6+Math.random()*6}px;height:${6+Math.random()*6}px;border-radius:${Math.random()>.5?'50%':'2px'};`;
    document.body.appendChild(p); setTimeout(()=>p.remove(),3500);
  }
}

function showSkeletonFil() {
  const feed=document.getElementById('fil-feed');
  if(!feed) return;
  feed.innerHTML=[1,2,3].map(()=>`<div class="skel-post"><div class="skel-row"><div class="skeleton skel-av"></div><div style="flex:1"><div class="skeleton skel-line" style="width:60%;margin-bottom:6px"></div><div class="skeleton skel-line" style="width:35%"></div></div></div><div class="skeleton skel-line" style="width:90%;margin-bottom:6px"></div><div class="skeleton skel-line" style="width:75%;margin-bottom:10px"></div><div class="skeleton skel-img"></div></div>`).join('');
}

function animateProfileStats() {
  document.querySelectorAll('#screen-profil .prof-stat-n').forEach(el=>{
    const raw=el.textContent; const isK=raw.includes('k'); const target=parseFloat(raw)*( isK?1000:1);
    if(!target) return; el.classList.add('counting');
    const start=performance.now(), dur=700;
    function upd(now){ const p=Math.min((now-start)/dur,1), e=1-Math.pow(1-p,3), v=Math.round(target*e);
      el.textContent=v>=1000?(v/1000).toFixed(1)+'k':v; if(p<1) requestAnimationFrame(upd); else{el.classList.remove('counting');el.textContent=raw;} }
    requestAnimationFrame(upd);
  });
}

function updateBadge(count) {
  ['tb-badge','bn-badge'].forEach(id=>{ const el=document.getElementById(id); if(!el) return;
    if(count>0){ el.style.display='block'; el.classList.remove('badge-pop'); void el.offsetWidth; el.classList.add('badge-pop'); }
    else el.style.display='none';
  });
}

const _origToggleLike = toggleLike;
function toggleLike(id) {
  _origToggleLike(id);
  const btn=document.querySelector(`#post-${id} .p-act.liked`);
  if(btn){ triggerLikeBurst(btn); btn.style.transform='scale(1.3)'; setTimeout(()=>{btn.style.transform='';},200); }
}

const _origPublishPost = publishPost;
function publishPost() {
  _origPublishPost();
  setTimeout(()=>{ if(document.getElementById('pub-success')?.style.display!=='none') launchConfetti(50); },1300);
}

const _origSubmitSignup = submitSignup;
function submitSignup() {
  _origSubmitSignup();
  setTimeout(()=>launchConfetti(60),1400);
}

document.addEventListener('DOMContentLoaded',()=>{
  const c=document.getElementById('compose-input');
  if(c) c.addEventListener('input',function(){this.style.height='auto';this.style.height=Math.min(this.scrollHeight,120)+'px';});
});

document.addEventListener('click',e=>{
  const story=e.target.closest('.story');
  if(story){ story.style.transform='scale(.92)'; setTimeout(()=>{story.style.transform='';},150); }
});

const _origToggleDark = toggleDark;
function toggleDark() {
  _origToggleDark();
  const btn=document.getElementById('dark-toggle');
  if(btn){ btn.style.transform='scale(1.2) rotate(15deg)'; setTimeout(()=>{btn.style.transform='';},250); }
}

const _origRenderFil = renderFil;
function renderFil() { showSkeletonFil(); setTimeout(_origRenderFil,400); }

window.addEventListener('load',()=>{
  const first=document.querySelector('.bn.active');
  if(first) slideNavIndicator(first);
  applyReveal(document.getElementById('screen-fil'));
});

function renderReactionsBar(pid) {
  const data = REACTIONS_DATA[pid];
  if(!data) return '';
  return '<div class="reactions-bar">' +
    Object.entries(data.emojis).map(([e,n])=>`<button class="reaction-btn${userReactions[pid]===e?' active':''}" onclick="toggleReaction(${pid},'${e}')">${e}<span class="reaction-count">${n}</span></button>`).join('') +
    '</div>';
}

function renderCommentsSection(pid) {
  const comments = COMMENTS_DATA[pid] || [];
  const isOpen = openComments.has(pid);
  const total = comments.reduce((a,c)=>a+1+c.replies.length, 0);
  const visible = isOpen ? comments : comments.slice(0,2);
  const replyInd = replyingTo && replyingTo.postId===pid
    ? `<div class="reply-indicator show" id="ri-${pid}"><span class="reply-indicator-text">↩ Répondre à ${replyingTo.name}</span><button class="reply-cancel" onclick="cancelReply(${pid})">✕</button></div>`
    : `<div class="reply-indicator" id="ri-${pid}"></div>`;
  return `
    <div class="comments-section" id="cs-${pid}">
      <div class="comments-header" onclick="toggleComments(${pid})">
        <span class="comments-header-lbl">💬 ${total} commentaire${total>1?'s':''}</span>
        <span class="comments-header-arrow${isOpen?' open':''}" id="ca-${pid}">▾</span>
      </div>
      <div id="cl-${pid}" style="display:${isOpen?'block':'none'}">
        <div class="comment-list" id="clist-${pid}">
          ${visible.map(c=>renderComment(pid,c)).join('')}
        </div>
        ${!isOpen||comments.length<=2?'':comments.length>visible.length?`<button class="show-more-comments" onclick="showMoreComments(${pid})">Voir les ${comments.length-2} commentaires suivants ▾</button>`:''}
        ${replyInd}
        <div class="comment-composer">
          <div class="cc-av">KM</div>
          <div class="cc-input-wrap">
            <button class="cc-emoji-btn" onclick="insertEmoji(${pid})">😊</button>
            <input class="cc-input" id="cc-${pid}" placeholder="Ajouter un commentaire…" onkeydown="if(event.key==='Enter')submitComment(${pid})" oninput="document.getElementById('cc-send-${pid}').disabled=!this.value.trim()">
            <button class="cc-send" id="cc-send-${pid}" disabled onclick="submitComment(${pid})">➤</button>
          </div>
        </div>
      </div>
    </div>`;
}

function renderComment(pid, c, isReply=false) {
  const user = c.user;
  return `<div class="comment-item${isReply?' reply':''}" id="citem-${c.id}">
    <div class="c-av${isReply?' sm':''}" style="background:${user.color}">${user.init}</div>
    <div class="c-body">
      <div class="c-bubble">
        <div class="c-name">${user.name}</div>
        <div class="c-text">${c.text}</div>
      </div>
      <div class="c-actions">
        <button class="c-action${c.liked?' liked':''}" onclick="toggleCommentLike(${pid},${c.id},${isReply})">
          ${c.liked?'❤️':'🤍'} ${c.likes>0?c.likes:''}
        </button>
        ${!isReply?`<button class="c-action" onclick="startReply(${pid},${c.id},'${user.name.split(' ')[0]}')">↩ Répondre</button>`:''}
        <span class="c-time">${c.time}</span>
      </div>
      ${!isReply&&c.replies&&c.replies.length>0?`<div class="replies-list" id="replies-${c.id}">${c.replies.map(r=>renderComment(pid,r,true)).join('')}</div>`:''}
    </div>
  </div>`;
}

function renderFil() {
  document.getElementById('fil-feed').innerHTML = filPosts.map(p=>`
    <div class="post-card" id="post-${p.id}">
      <div class="post-hd">
        <div class="p-av" style="background:${p.user.color}">${p.user.init}</div>
        <div class="p-meta"><div class="p-name">${p.user.name}</div><div class="p-time">il y a ${p.time}</div></div>
        <button class="p-more">⋯</button>
      </div>
      <div class="p-text">${p.text}</div>
      ${p.imgUrl ? `<img src="${p.imgUrl}" style="width:100%;max-height:280px;object-fit:cover;border-radius:var(--radius);margin-bottom:10px;display:block;" alt="Post image">` : `<div class="p-img">${p.emoji}</div>`}
      <div class="p-actions">
        <button class="p-act${p.liked?' liked':''}" onclick="toggleLike(${p.id})"><span class="p-act-icon">❤️</span>${p.likes}</button>
        <button class="p-act" onclick="toggleComments(${p.id})"><span class="p-act-icon">💬</span><span id="ccount-${p.id}">${(COMMENTS_DATA[p.id]||[]).reduce((a,c)=>a+1+c.replies.length,0)||p.comments}</span></button>
        <button class="p-act"><span class="p-act-icon">🔁</span></button>
        <button class="p-act" style="margin-left:auto"><span class="p-act-icon">🔖</span></button>
      </div>
      ${renderReactionsBar(p.id)}
      ${renderCommentsSection(p.id)}
    </div>`).join('');
}

function toggleLike(id) {
  const p = filPosts.find(x=>x.id===id);
  if(!p) return;
  p.liked=!p.liked; p.likes+=p.liked?1:-1;
  renderFil();
}

function addPost() {
  const inp = document.getElementById('compose-input');
  const text = inp.value.trim(); if(!text) return;
  const emojis=['✨','🌅','🌍','📸','🌺','💫'];
  filPosts.unshift({id:nextId++,user:{init:'KM',color:'#085041',name:'Keza Mutoni'},time:"à l'instant",text,emoji:emojis[Math.floor(Math.random()*emojis.length)],likes:0,comments:0,liked:false});
  inp.value=''; renderFil();
}

function renderExpContent(cat) {
  const c = document.getElementById('exp-content');
  const emojis = EXP_GRIDS[cat] || EXP_GRIDS.tout;

  if(cat==='personnes'){
    c.innerHTML=`<div class="sec-title" style="margin-top:10px">👥 Personnes suggérées <span class="sec-all">Voir tout</span></div>
      <div class="suggest-row">${PEOPLE.map((p,i)=>`
        <div class="sug-card">
          <div class="sug-av" style="background:${p.color}">${p.init}</div>
          <div class="sug-name">${p.name.split(' ')[0]}</div>
          <div class="sug-handle">${p.handle}</div>
          <div class="sug-fol">${p.followers} abonnés</div>
          <button class="sug-btn${p.following?' following':''}" onclick="toggleExpFollow(${i},this)">${p.following?'Abonné·e':"S'abonner"}</button>
        </div>`).join('')}</div>`;
    return;
  }

  if(cat==='evenements'){
    c.innerHTML=`<div class="sec-title" style="margin-top:10px">🎉 Événements <span class="sec-all">Voir tout</span></div>
      ${[['14','Juin','Kigali Photo Walk','📍 Kigali · 🕕 18h'],['21','Juin','AfrikaFood Festival 🍽️','📍 Dakar · 🕙 10h'],['30','Juin','Life Bao Creator Summit','📍 Abidjan · 🕙 9h']].map((ev,i)=>`
      <div class="event-card">
        <div class="ev-date"><div class="ev-day">${ev[0]}</div><div class="ev-month">${ev[1]}</div></div>
        <div class="ev-info"><div class="ev-name">${ev[2]}</div><div class="ev-meta">${ev[3]}</div></div>
        <button class="ev-btn" id="evb${i}" onclick="joinEv(${i})">Rejoindre</button>
      </div>`).join('')}`;
    return;
  }

  if(cat==='live'){
    c.innerHTML=`<div class="sec-title" style="margin-top:10px">🔴 Lives en cours <span class="sec-all">Voir tout</span></div>
      ${[{av:'AD',color:'#1D9E75',bg:'linear-gradient(135deg,#085041,#1D9E75)',e:'🌅',title:'Séance photo au coucher de soleil',host:'Amina Diallo · Kigali',v:'1 247'},
         {av:'FS',color:'#993556',bg:'linear-gradient(135deg,#993556,#534AB7)',e:'🍛',title:'Cours de cuisine africaine',host:'Fatou Sow · Dakar',v:'538'}].map(l=>`
      <div class="live-card">
        <div class="live-thumb" style="background:${l.bg}">${l.e}<div class="live-badge"><span class="live-dot"></span>DIRECT</div><div class="live-viewers">👁 ${l.v}</div></div>
        <div class="live-info"><div class="live-av" style="background:${l.color}">${l.av}</div><div class="live-meta"><div class="live-title">${l.title}</div><div class="live-host">${l.host}</div></div><button class="live-join">Rejoindre</button></div>
      </div>`).join('')}`;
    return;
  }

  const showAll = cat==='tout';
  c.innerHTML=`
    ${showAll?`<div class="hero-card">
      <div class="hc-tag">🔥 Tendance</div>
      <div class="hc-title">Kigali Creative Week 2026</div>
      <div class="hc-sub">Les artistes africains réunis 🌍</div>
      <button class="hc-btn">Explorer →</button>
      <div class="hc-stats">
        <div><div class="hc-stat-n">12.4k</div><div class="hc-stat-l">posts</div></div>
        <div><div class="hc-stat-n">3.2k</div><div class="hc-stat-l">participants</div></div>
      </div>
    </div>
    <div class="sec-title">🔥 Tags tendance <span class="sec-all">Voir tout</span></div>
    <div class="tags-wrap">
      ${[['#KigaliVibe','24.3k posts','↑+42%'],['#AfrikaFood','18.1k posts','↑+28%'],['#LifeBao','51.7k posts','↑+15%'],['#SunsetAfrica','9.8k posts','↑+67%']].map(([n,c,h])=>`<div class="tag-pill"><div class="tag-pill-name">${n}</div><div class="tag-pill-count">${c}</div><div class="tag-pill-heat">${h}</div></div>`).join('')}
    </div>`:''}

    <div class="sec-title">${{tout:'📸 Posts populaires',photos:'📸 Photos',videos:'🎬 Vidéos',food:'🍛 Food',art:'🎨 Art'}[cat]||'📸 Posts'} <span class="sec-all">Voir tout</span></div>
    <div class="masonry">${emojis.map((e,i)=>`
      <div class="m-item" style="background:${EXP_COLORS[i%EXP_COLORS.length]}">
        <span class="m-emoji">${e}</span>
        <div class="m-overlay">
          <div class="m-ov-user"><div class="m-ov-av" style="background:${PEOPLE[i%PEOPLE.length].color}">${PEOPLE[i%PEOPLE.length].init}</div><div class="m-ov-name">${PEOPLE[i%PEOPLE.length].name.split(' ')[0]}</div></div>
          <div class="m-ov-stats">❤️ ${(Math.floor(Math.random()*19+1)*100)} · 💬 ${Math.floor(Math.random()*100+5)}</div>
        </div>
      </div>`).join('')}</div>

    ${showAll?`<div class="sec-title">👥 Personnes suggérées <span class="sec-all">Voir tout</span></div>
    <div class="suggest-row">${PEOPLE.slice(0,4).map((p,i)=>`
      <div class="sug-card"><div class="sug-av" style="background:${p.color}">${p.init}</div><div class="sug-name">${p.name.split(' ')[0]}</div><div class="sug-handle">${p.handle}</div><div class="sug-fol">${p.followers}</div><button class="sug-btn${p.following?' following':''}" onclick="toggleExpFollow(${i},this)">${p.following?'Abonné·e':"S'abonner"}</button></div>`).join('')}</div>
    <div class="sec-title">🌈 Thématiques <span class="sec-all">Voir tout</span></div>
    <div class="topics-grid">
      <div class="topic-card" style="background:linear-gradient(135deg,#085041,#1D9E75)"><div class="topic-emoji">📸</div><div class="topic-name">Photographie</div><div class="topic-count">8.3k posts</div></div>
      <div class="topic-card" style="background:linear-gradient(135deg,#854F0B,#FAC775)"><div class="topic-emoji">🍛</div><div class="topic-name">Food africaine</div><div class="topic-count">5.1k posts</div></div>
      <div class="topic-card" style="background:linear-gradient(135deg,#185FA5,#534AB7)"><div class="topic-emoji">🎵</div><div class="topic-name">Musique</div><div class="topic-count">4.7k posts</div></div>
      <div class="topic-card" style="background:linear-gradient(135deg,#993556,#D85A30)"><div class="topic-emoji">🌍</div><div class="topic-name">Voyages</div><div class="topic-count">3.7k posts</div></div>
    </div>`:''}
    <div style="height:70px"></div>`;
}

function switchChip(el, cat) {
  document.querySelectorAll('.chip').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');
  activeExpCat = cat;
  clearExpSearch();
  renderExpContent(cat);
}

function handleExpSearch(val) {
  const sx = document.getElementById('exp-sx');
  const res = document.getElementById('exp-results');
  const bar = document.getElementById('chips-bar');
  const cont = document.getElementById('exp-content');
  sx.style.display = val ? 'block' : 'none';
  if(!val.trim()){
    res.style.display='none'; bar.style.display='flex'; cont.style.display='block'; return;
  }
  bar.style.display='none'; cont.style.display='none'; res.style.display='block';
  const q = val.toLowerCase();
  const found = SEARCH_INDEX.filter(x=>x.name.toLowerCase().includes(q)||(x.sub||'').toLowerCase().includes(q));
  res.innerHTML = found.length===0
    ? '<div class="sr-empty">Aucun résultat 🔍</div>'
    : found.map(r=>r.type==='person'
        ? `<div class="sr-item"><div class="sr-av" style="background:${r.color}">${r.init}</div><div><div class="sr-name">${r.name}</div><div class="sr-sub">${r.sub}</div></div></div>`
        : `<div class="sr-item"><div class="sr-ico">${r.type==='tag'?'#️⃣':'🎉'}</div><div><div class="sr-name">${r.name}</div><div class="sr-sub">${r.sub||''}</div></div></div>`
      ).join('') + '<div style="height:70px"></div>';
}

function clearExpSearch() {
  const inp = document.getElementById('exp-input'); if(inp) inp.value='';
  document.getElementById('exp-sx').style.display='none';
  document.getElementById('exp-results').style.display='none';
  document.getElementById('chips-bar').style.display='flex';
  document.getElementById('exp-content').style.display='block';
}

function toggleExpFollow(idx, btn) {
  PEOPLE[idx].following = !PEOPLE[idx].following;
  btn.classList.toggle('following');
  btn.textContent = PEOPLE[idx].following ? 'Abonné·e' : "S'abonner";
}

function joinEv(idx) {
  const btn = document.getElementById('evb'+idx);
  if(btn){btn.textContent='✓ Inscrit';btn.disabled=true;}
}

const PUB_TYPES = {
  photo:{dzMain:'Glisse ta photo ici',dzSub:'JPG, PNG · max 20 Mo',emojis:['🌅','📸','🌺','🦁','🌍','🎞️']},
  video:{dzMain:'Glisse ta vidéo ici',dzSub:'MP4, MOV · max 500 Mo',emojis:['🎬','🎥','📹','🎭','🎤']},
  story:{dzMain:'Crée ta story',dzSub:'Photo ou vidéo · max 60 sec',emojis:['✨','🌟','💫','🎉','❤️']},
  live: {dzMain:'Démarre ton live',dzSub:'Diffusion en direct',emojis:['📡','🔴','🎙️','📺']},
};

const FILE_ACCEPT = {
  photo:'image/*',
  video:'video/*',
  story:'image/*,video/*',
  live: null,
};

let selectedFiles = []; // array of {file, url, type}

function switchPubType(el, type) {
  document.querySelectorAll('.pub-type').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  activePubType = type;
  resetDz();
  const cfg = PUB_TYPES[type];
  document.getElementById('dz-main').textContent = cfg.dzMain;
  document.getElementById('dz-sub').textContent = cfg.dzSub;
  // Update file input accept
  const fi = document.getElementById('file-input');
  if(fi) {
    fi.accept = FILE_ACCEPT[type] || 'image/*,video/*';
    fi.multiple = (type !== 'live');
  }
  // Live mode: show direct start UI
  if(type==='live') {
    document.getElementById('dz-main').textContent = 'Démarrer un live';
    document.getElementById('dz-sub').textContent = 'Diffusion en direct vers tes abonnés Bao';
  }
}

function triggerFileInput() {
  if(activePubType === 'live') { startLiveMode(); return; }
  document.getElementById('file-input').click();
}

function handleFileSelect(input) {
  const files = Array.from(input.files);
  if(!files.length) return;
  processFiles(files);
  input.value = ''; // reset so same file can be re-selected
}

function handleDragOver(e) {
  e.preventDefault(); e.stopPropagation();
  document.getElementById('pub-dz').classList.add('dragover');
}
function handleDragLeave(e) {
  e.preventDefault();
  document.getElementById('pub-dz').classList.remove('dragover');
}
function handleDrop(e) {
  e.preventDefault(); e.stopPropagation();
  document.getElementById('pub-dz').classList.remove('dragover');
  const files = Array.from(e.dataTransfer.files);
  if(files.length) processFiles(files);
}

function processFiles(files) {
  const allowed = files.filter(f => f.type.startsWith('image/') || f.type.startsWith('video/'));
  if(!allowed.length) {
    showFileError('Format non supporté. Utilise JPG, PNG, MP4 ou MOV.'); return;
  }
  // Check sizes
  const tooBig = allowed.filter(f => f.size > 500 * 1024 * 1024);
  if(tooBig.length) { showFileError(`Fichier trop volumineux (max 500 Mo par fichier).`); return; }

  // Revoke old URLs
  selectedFiles.forEach(sf => { if(sf.url) URL.revokeObjectURL(sf.url); });
  selectedFiles = [];

  allowed.slice(0,4).forEach(file => {
    const url = URL.createObjectURL(file);
    selectedFiles.push({file, url, type: file.type.startsWith('video/') ? 'video' : 'image'});
  });

  renderFilePreview();
}

function renderFilePreview() {
  if(!selectedFiles.length) { resetDz(); return; }
  document.getElementById('dz-empty').style.display='none';
  document.getElementById('dz-preview').style.display='block';
  document.getElementById('pub-dz').classList.add('picked');
  pubHasMedia = true;
  document.getElementById('pub-submit').disabled = false;

  const inner = document.getElementById('dz-preview-inner');
  const info = document.getElementById('dz-file-info');

  if(selectedFiles.length === 1) {
    const sf = selectedFiles[0];
    if(sf.type === 'video') {
      inner.innerHTML = `<video class="dz-media-video" src="${sf.url}" controls playsinline></video>`;
    } else {
      inner.innerHTML = `<img class="dz-media-img" src="${sf.url}" alt="Aperçu">`;
    }
    info.textContent = `📄 ${sf.file.name} · ${formatSize(sf.file.size)}`;
  } else {
    inner.innerHTML = `<div class="multi-preview">
      ${selectedFiles.map((sf,i) => `
        <div class="multi-thumb">
          ${sf.type==='video'
            ? `<video src="${sf.url}" style="width:100%;height:100%;object-fit:cover;"></video><div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.3);font-size:28px;">▶️</div>`
            : `<img src="${sf.url}" alt="Photo ${i+1}">`}
          <button class="multi-thumb-rm" onclick="removeFile(${i})">✕</button>
        </div>`).join('')}
      ${selectedFiles.length < 4 ? `<div class="multi-add" onclick="triggerFileInput()"><div>➕</div><div style="font-size:10px;margin-top:4px">Ajouter</div></div>` : ''}
    </div>`;
    info.textContent = `${selectedFiles.length} fichier${selectedFiles.length>1?'s':''} sélectionné${selectedFiles.length>1?'s':''}`;
  }
}

function removeFile(idx) {
  if(selectedFiles[idx]) URL.revokeObjectURL(selectedFiles[idx].url);
  selectedFiles.splice(idx, 1);
  if(!selectedFiles.length) resetDz();
  else renderFilePreview();
}

function formatSize(bytes) {
  if(bytes < 1024*1024) return (bytes/1024).toFixed(0)+'Ko';
  return (bytes/(1024*1024)).toFixed(1)+'Mo';
}

function showFileError(msg) {
  const sub = document.getElementById('dz-sub');
  if(sub) { sub.style.color='var(--coral)'; sub.textContent=msg; setTimeout(()=>{sub.style.color='';sub.textContent=PUB_TYPES[activePubType].dzSub;},3000); }
}

function startLiveMode() {
  document.getElementById('dz-empty').style.display='none';
  document.getElementById('dz-preview').style.display='block';
  document.getElementById('pub-dz').classList.add('picked');
  pubHasMedia = true;
  document.getElementById('pub-submit').disabled = false;
  document.getElementById('pub-submit').textContent = '🔴 Démarrer le live';
  document.getElementById('dz-preview-inner').innerHTML = `
    <div style="height:170px;background:linear-gradient(135deg,#1a0505,#4a0d0d);border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;">
      <div style="font-size:40px">📡</div>
      <div style="color:#fff;font-size:13px;font-weight:500">Prêt à diffuser en direct</div>
      <div style="background:#D85A30;color:#fff;font-size:10px;font-weight:500;border-radius:20px;padding:3px 12px;display:flex;align-items:center;gap:5px;">
        <span style="width:6px;height:6px;border-radius:50%;background:#fff;animation:blink 1s infinite;display:inline-block"></span>EN DIRECT
      </div>
    </div>`;
  document.getElementById('dz-file-info').textContent = 'La caméra sera activée au démarrage';
}

function resetDz() {
  selectedFiles.forEach(sf => { if(sf.url) URL.revokeObjectURL(sf.url); });
  selectedFiles = [];
  pubHasMedia = false;
  document.getElementById('dz-empty').style.display='flex';
  document.getElementById('dz-preview').style.display='none';
  document.getElementById('pub-dz').classList.remove('picked','dragover');
  document.getElementById('pub-submit').disabled = true;
  document.getElementById('pub-submit').textContent = 'Publier';
  if(document.getElementById('dz-preview-inner')) document.getElementById('dz-preview-inner').innerHTML='';
  if(document.getElementById('dz-file-info')) document.getElementById('dz-file-info').textContent='';
}

function publishPost() {
  const btn = document.getElementById('pub-submit');
  btn.textContent='Publication en cours…'; btn.disabled=true;

  // Simulate upload progress
  let progress = 0;
  const interval = setInterval(()=>{
    progress += Math.random()*25;
    if(progress >= 100) {
      clearInterval(interval);
      finishPublish(btn);
    } else {
      btn.textContent=`Envoi… ${Math.min(99,Math.floor(progress))}%`;
    }
  }, 200);
}

function finishPublish(btn) {
  const cap = document.getElementById('pub-caption').value || 'Nouveau post ✨';
  // Use first file preview or fallback emoji
  let postEmoji = '✨';
  if(selectedFiles.length && selectedFiles[0].type==='image') {
    postEmoji = selectedFiles[0].url; // will be used as img src
  } else if(selectedFiles.length && selectedFiles[0].type==='video') {
    postEmoji = '🎬';
  } else {
    const cfg = PUB_TYPES[activePubType];
    postEmoji = cfg.emojis[0];
  }

  const isRealImg = postEmoji.startsWith('blob:');
  filPosts.unshift({
    id:nextId++,
    user:{init:'KM',color:'#085041',name:'Keza Mutoni'},
    time:"à l'instant",
    text:cap,
    emoji: isRealImg ? null : postEmoji,
    imgUrl: isRealImg ? postEmoji : null,
    likes:0,comments:0,liked:false
  });
  renderFil();
  document.getElementById('pub-main').style.display='none';
  document.getElementById('pub-success').style.display='flex';
  if(btn) { btn.textContent='Publier'; btn.disabled=false; }
}

function resetPub() {
  document.getElementById('pub-main').style.display='block';
  document.getElementById('pub-success').style.display='none';
  document.getElementById('pub-caption').value='';
  document.getElementById('cap-count').textContent='0/280';
  resetDz();
  document.querySelectorAll('.pub-type').forEach((t,i)=>t.classList.toggle('active',i===0));
  activePubType='photo';
  document.getElementById('dz-main').textContent=PUB_TYPES.photo.dzMain;
  document.getElementById('dz-sub').textContent=PUB_TYPES.photo.dzSub;
}

const NOTIF_TYPE_MAP = {mentions:'mention',aimes:'like',abonnes:'follow',commentaires:'comment',live:'live'};
const SIM = {
  like:   {type:'like',  emoji:'❤️',thumb:'🎞️',texts:["a aimé ta photo","a aimé ton post"]},
  follow: {type:'follow',emoji:'👤',thumb:null, texts:["s'est abonné·e à toi"],actions:true},
  comment:{type:'comment',emoji:'💬',thumb:'🌅',texts:['a commenté : <b>"Superbe 🔥"</b>',"a répondu à ton commentaire"]},
  mention:{type:'mention',emoji:'🏷️',thumb:'📸',texts:["t'a mentionné dans un post"]},
  live:   {type:'live',  emoji:'🔴',thumb:null, texts:['est en live maintenant'],live:true},
};

function renderNotifs() {
  const list = activeNotifTab==='tous' ? notifs : notifs.filter(n=>n.type===NOTIF_TYPE_MAP[activeNotifTab]);
  const unread = notifs.filter(n=>n.unread).length;
  document.getElementById('notif-unread-lbl').textContent = unread>0 ? `${unread} non lue${unread>1?'s':''}` : 'Tout est lu ✓';
  updateBadge(unread);
  if(list.length===0){
    document.getElementById('notif-list').innerHTML='<div class="notif-empty"><div class="notif-empty-icon">🔔</div><div style="font-size:13px;color:var(--muted)">Aucune notification ici</div></div>';
    return;
  }
  let html='', lastGrp='';
  list.forEach(n=>{
    if(n.group!==lastGrp){html+=`<div class="n-grp-lbl">${n.group}</div>`;lastGrp=n.group;}
    html+=`<div class="n-item${n.unread?' unread':''}" onclick="readNotif(${n.id})">
      ${n.unread?'<div class="n-dot"></div>':''}
      <div class="n-av-wrap"><div class="n-av" style="background:${n.user.color}">${n.user.init}</div><div class="n-emoji">${n.emoji}</div></div>
      <div class="n-body">
        <div class="n-text"><b>${n.user.name}</b> ${n.text}${n.live?'<span class="live-pill"><span class="live-dot"></span>LIVE</span>':''}</div>
        <div class="n-time">${n.time}</div>
        ${n.actions?'<div class="n-actions"><button class="n-act p" onclick="event.stopPropagation();followBackNotif(this)">Suivre aussi</button><button class="n-act s" onclick="event.stopPropagation()">Ignorer</button></div>':''}
        ${n.live?'<div class="n-actions"><button class="n-act p" onclick="event.stopPropagation()">🔴 Rejoindre</button></div>':''}
      </div>
      ${n.thumb?`<div class="n-thumb">${n.thumb}</div>`:''}
    </div>`;
  });
  document.getElementById('notif-list').innerHTML=html;
}

function readNotif(id){const n=notifs.find(x=>x.id===id);if(n)n.unread=false;renderNotifs();}
function markAllRead(){notifs.forEach(n=>n.unread=false);renderNotifs();}
function followBackNotif(btn){btn.textContent='Abonné·e ✓';btn.style.background='var(--green-mid)';btn.disabled=true;}
function switchNotifTab(el,tab){document.querySelectorAll('.ntab').forEach(t=>t.classList.remove('active'));el.classList.add('active');activeNotifTab=tab;renderNotifs();}

function simulate(type){
  const tpl=SIM[type];
  const u=PEOPLE[Math.floor(Math.random()*PEOPLE.length)];
  const txt=tpl.texts[Math.floor(Math.random()*tpl.texts.length)];
  const n={id:nextId++,type:tpl.type,user:u,text:txt,emoji:tpl.emoji,thumb:tpl.thumb||null,time:"à l'instant",unread:true,group:"Aujourd'hui",actions:tpl.actions||false,live:tpl.live||false};
  notifs.unshift(n);
  renderNotifs();
  showToast(n);
}

function updateBadge(count){
  ['tb-badge','bn-badge'].forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.style.display=count>0?'block':'none';
  });
}

function hideBadges(){updateBadge(0);}

function showToast(n){
  const host=document.getElementById('toast-host');
  const div=document.createElement('div');
  div.className='toast';
  div.innerHTML=`<div class="t-av" style="background:${n.user.color}">${n.user.init}</div><div class="t-body"><div class="t-name">${n.user.name}</div><div class="t-msg">${n.text.replace(/<[^>]+>/g,'')}</div></div><div style="font-size:18px">${n.emoji}</div><button class="t-close" onclick="dismissToast(this.parentElement)">×</button>`;
  div.onclick=(e)=>{if(!e.target.classList.contains('t-close')){dismissToast(div);}};
  host.prepend(div);
  setTimeout(()=>dismissToast(div),4000);
}

function dismissToast(el){if(!el||el.classList.contains('out'))return;el.classList.add('out');setTimeout(()=>el.remove(),300);}

function renderConvos(){
  document.getElementById('convo-list').innerHTML=CONVOS.map(c=>`
    <div class="convo-item" onclick="openChat(${c.id})">
      <div class="convo-av" style="background:${c.user.color}">${c.user.init}${c.user.online?'<span class="online"></span>':''}</div>
      <div class="convo-info"><div class="convo-name">${c.user.name}</div><div class="convo-prev">${c.prev}</div></div>
      <div class="convo-meta"><span class="convo-time">${c.time}</span>${c.unread?`<span class="convo-badge">${c.unread}</span>`:''}</div>
    </div>`).join('');
}

function openChat(id){
  activeChat=id;
  CONVOS[id].unread=0;
  const u=CONVOS[id].user;
  document.getElementById('chat-av').style.background=u.color;
  document.getElementById('chat-av').textContent=u.init;
  document.getElementById('chat-name').textContent=u.name;
  document.getElementById('chat-status').textContent=u.online?'En ligne':'Hors ligne';
  document.getElementById('chat-status').style.color=u.online?'var(--green-mid)':'var(--muted)';
  renderConvos();
  document.getElementById('msg-list-view').style.display='none';
  document.getElementById('chat-screen').classList.add('open');
  renderThread();
}

function closeChat(){
  document.getElementById('chat-screen').classList.remove('open');
  document.getElementById('msg-list-view').style.display='block';
}

function renderThread(){
  const msgs=THREADS[activeChat]||[];
  const u=CONVOS[activeChat].user;
  const el=document.getElementById('msgs-area');
  el.innerHTML='<div class="day-sep">Aujourd\'hui</div>'+msgs.map(m=>`
    <div class="msg-row${m.me?' me':''}">
      ${!m.me?`<div class="msg-mini-av" style="background:${u.color}">${u.init}</div>`:''}
      <div class="bubble">${m.text}</div>
    </div>`).join('');
  el.scrollTop=el.scrollHeight;
}

function sendMsg(){
  const inp=document.getElementById('chat-input');
  const txt=inp.value.trim(); if(!txt) return;
  THREADS[activeChat]=THREADS[activeChat]||[];
  THREADS[activeChat].push({me:true,text:txt});
  CONVOS[activeChat].prev=txt;
  inp.value=''; renderThread();
  // typing indicator then auto-reply
  const el=document.getElementById('msgs-area');
  const typDiv=document.createElement('div');
  typDiv.className='typing-row'; typDiv.id='typ';
  const u=CONVOS[activeChat].user;
  typDiv.innerHTML=`<div class="msg-mini-av" style="background:${u.color}">${u.init}</div><div class="typing-bubble"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>`;
  el.appendChild(typDiv); el.scrollTop=el.scrollHeight;
  const replies=["Super 😊","Ok !","Haha 😄","On se voit bientôt ✨","💚","D'accord !","Vraiment ? 😮"];
  setTimeout(()=>{
    document.getElementById('typ')?.remove();
    const rep=replies[Math.floor(Math.random()*replies.length)];
    THREADS[activeChat].push({me:false,text:rep});
    CONVOS[activeChat].prev=rep;
    renderThread();
    renderConvos();
  },1500);
}

function renderProfGrid(){
  const emojis=['🌅','📸','🌺','🦁','🌍','🎞️','🌸','🏙️','🥭'];
  document.getElementById('prof-tab-content').innerHTML='<div class="photo-grid">'+emojis.map(e=>`<div class="pg-cell">${e}</div>`).join('')+'</div>';
}

function switchProfTab(el,type){
  document.querySelectorAll('.ptab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  if(type==='grid') renderProfGrid();
  else document.getElementById('prof-tab-content').innerHTML=filPosts.slice(0,3).map(p=>`
    <div class="post-card"><div class="p-text" style="margin-bottom:8px">${p.emoji} ${p.text}</div>
    <div class="p-actions"><button class="p-act"><span class="p-act-icon">❤️</span>${p.likes}</button><button class="p-act"><span class="p-act-icon">💬</span>${p.comments}</button></div></div>`).join('');
}

function openSubPanel(name){
  closeSubPanel();
  const p=document.getElementById('sp-'+name);
  if(p){p.classList.add('open');p.scrollTop=0;}
}
function closeSubPanel(){document.querySelectorAll('.sub-panel').forEach(p=>p.classList.remove('open'));}
function savePanel(btn){
  const orig=btn.textContent;
  btn.textContent='✓ Enregistré !';btn.style.background='var(--green-mid)';
  setTimeout(()=>{btn.textContent=orig;btn.style.background='';},1800);
}

function pickOpt(el,group){
  document.querySelectorAll('.'+group+'-opt').forEach(o=>o.classList.remove('active'));
  el.classList.add('active');
}

let currentTheme = 'light'; // 'light' | 'dark' | 'system'
const ROOT = document.documentElement;

function applyTheme(mode, el) {
  currentTheme = mode;
  // update settings buttons
  ['light','dark','system'].forEach(m => {
    const opt = document.getElementById('theme-opt-'+m);
    if(opt) opt.classList.toggle('active', m===mode);
  });

  let isDark;
  if(mode==='system') isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  else isDark = mode==='dark';

  ROOT.setAttribute('data-theme', isDark ? 'dark' : 'light');
  updateToggleBtn(isDark);
  localStorage.setItem('lifebao-theme', mode);
}

function toggleDark() {
  if(currentTheme==='dark') applyTheme('light');
  else applyTheme('dark');
}

function updateToggleBtn(isDark) {
  const icon = document.getElementById('dark-toggle-icon');
  const lbl  = document.getElementById('dark-toggle-label');
  if(icon) icon.textContent = isDark ? '☀️' : '🌙';
  if(lbl)  lbl.textContent  = isDark ? 'Clair' : 'Sombre';
}

// Detect system preference changes
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
  if(currentTheme==='system') {
    ROOT.setAttribute('data-theme', e.matches ? 'dark' : 'light');
    updateToggleBtn(e.matches);
  }
});

// On load: restore saved preference or detect system
(function initTheme() {
  const saved = localStorage.getItem('lifebao-theme') || 'system';
  currentTheme = saved;
  let isDark;
  if(saved==='system') isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  else isDark = saved==='dark';
  ROOT.setAttribute('data-theme', isDark ? 'dark' : 'light');
  updateToggleBtn(isDark);
  // Sync settings buttons
  ['light','dark','system'].forEach(m => {
    const opt = document.getElementById('theme-opt-'+m);
    if(opt) opt.classList.toggle('active', m===saved);
  });
})();

const myPages = [
  {name:'Keza Photo Studio',cat:'📷 Photographie',loc:'Kigali',desc:'Séances photo professionnelles et portfolio artistique.',cover:'linear-gradient(135deg,#085041,#1D9E75)',emoji:'📸',followers:342,posts:48},
];
const myGroupes = [
  {name:'Photographes de Kigali',privacy:'🔒 Privé',cover:'linear-gradient(135deg,#185FA5,#534AB7)',emoji:'🌍',members:128,posts:24,role:'Admin'},
];
const suggestedPages = [
  {name:'AfrikaFood Blog',cat:'🍛 Food',followers:'12.4k',emoji:'🍛',color:'linear-gradient(135deg,#854F0B,#FAC775)'},
  {name:'Kigali Fashion Week',cat:'💄 Mode',followers:'8.2k',emoji:'👗',color:'linear-gradient(135deg,#993556,#D85A30)'},
  {name:'Rwanda Artisans',cat:'🎨 Art',followers:'5.7k',emoji:'🏺',color:'linear-gradient(135deg,#534AB7,#185FA5)'},
];
const suggestedGroupes = [
  {name:'Foodies de Dakar',privacy:'🌐 Public',members:'2.4k',emoji:'🍛',color:'linear-gradient(135deg,#854F0B,#FAC775)'},
  {name:'African Creators Hub',privacy:'🌐 Public',members:'5.1k',emoji:'🎬',color:'linear-gradient(135deg,#085041,#1D9E75)'},
  {name:'Entrepreneurs Afrique',privacy:'🔒 Privé',members:'892',emoji:'💼',color:'linear-gradient(135deg,#185FA5,#534AB7)'},
];

let activeComTab = 'pages';
let invitedPeople = [];
let selectedPrivacy = 'public';
const COVER_EMOJIS = {page:['📸','🌺','🌍','💼','🎨','🎵','🍛','🏋️'],groupe:['👥','🌍','📸','🎵','💼','🍛','🎨','⚽']};

function renderCommunaute() {
  // Suggested pages
  document.getElementById('suggested-pages').innerHTML = suggestedPages.map((p,i)=>`
    <div class="com-card">
      <div class="com-card-cover" style="background:${p.color}">${p.emoji}</div>
      <div class="com-card-body">
        <div class="com-card-name">${p.name}</div>
        <div class="com-card-meta"><span>${p.cat}</span><span>•</span><span>${p.followers} abonnés</span></div>
        <div class="com-card-actions">
          <button class="com-btn-p" id="sp-btn-${i}" onclick="followPage(${i},this)">S'abonner</button>
          <button class="com-btn-s">En savoir plus</button>
        </div>
      </div>
    </div>`).join('');

  // Suggested groupes
  document.getElementById('suggested-groupes').innerHTML = suggestedGroupes.map((g,i)=>`
    <div class="com-card">
      <div class="com-card-cover" style="background:${g.color}">${g.emoji}</div>
      <div class="com-card-body">
        <div class="com-card-name">${g.name}</div>
        <div class="com-card-meta"><span>${g.privacy}</span><span>•</span><span>${g.members} membres</span></div>
        <div class="com-card-actions">
          <button class="com-btn-p" id="sg-btn-${i}" onclick="joinGroupe(${i},this)">Rejoindre</button>
          <button class="com-btn-s">Aperçu</button>
        </div>
      </div>
    </div>`).join('');

  // Trending pages
  const tpEl = document.getElementById('trending-pages');
  if(tpEl) tpEl.innerHTML = [...suggestedPages,...myPages.map(p=>({name:p.name,cat:p.cat,followers:p.followers+'',emoji:p.emoji,color:p.cover}))].map(p=>`
    <div class="com-card" style="margin-bottom:8px">
      <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;">
        <div style="width:42px;height:42px;border-radius:10px;background:${p.color||'var(--green-light)'};display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0">${p.emoji}</div>
        <div style="flex:1"><div style="font-size:13px;font-weight:500;color:var(--text)">${p.name}</div><div style="font-size:11px;color:var(--muted)">${p.cat} · ${p.followers} abonnés</div></div>
        <button class="com-btn-p" style="padding:5px 12px;font-size:11px">S'abonner</button>
      </div>
    </div>`).join('');

  const tgEl = document.getElementById('trending-groupes');
  if(tgEl) tgEl.innerHTML = [...suggestedGroupes].map(g=>`
    <div class="com-card" style="margin-bottom:8px">
      <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;">
        <div style="width:42px;height:42px;border-radius:10px;background:${g.color};display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0">${g.emoji}</div>
        <div style="flex:1"><div style="font-size:13px;font-weight:500;color:var(--text)">${g.name}</div><div style="font-size:11px;color:var(--muted)">${g.privacy} · ${g.members} membres</div></div>
        <button class="com-btn-p" style="padding:5px 12px;font-size:11px">Rejoindre</button>
      </div>
    </div>`).join('');
}

function switchComTab(el, tab) {
  activeComTab = tab;
  ['pages','groupes','decouvrir'].forEach(t=>{
    const tabEl = document.getElementById('ct-'+t);
    const secEl = document.getElementById('com-'+t);
    const isActive = t===tab;
    if(tabEl){tabEl.style.color=isActive?'#fff':'rgba(255,255,255,0.6)';tabEl.style.borderBottomColor=isActive?'var(--sand)':'transparent';}
    if(secEl) secEl.style.display=isActive?'block':'none';
  });
}

function followPage(idx, btn) {
  btn.textContent='✓ Abonné'; btn.style.background='var(--green-mid)'; btn.disabled=true;
}
function joinGroupe(idx, btn) {
  btn.textContent='✓ Rejoint'; btn.style.background='var(--green-mid)'; btn.disabled=true;
}

function renderPageDetail(p) {
  document.getElementById('pd-title').textContent=p.name;
  document.getElementById('page-detail-content').innerHTML=`
    <div style="height:100px;background:${p.cover};display:flex;align-items:center;justify-content:center;font-size:60px">${p.emoji}</div>
    <div style="background:var(--card);padding:14px 16px;border-bottom:1px solid var(--border)">
      <div style="font-size:17px;font-weight:500;color:var(--text);margin-bottom:3px">${p.name}</div>
      <div style="font-size:12px;color:var(--muted);margin-bottom:8px">${p.cat} · ${p.loc}</div>
      <div style="font-size:13px;color:var(--text);margin-bottom:10px">${p.desc}</div>
      <div style="display:flex;gap:14px;margin-bottom:10px">
        <div style="text-align:center"><div style="font-size:15px;font-weight:500">${p.followers}</div><div style="font-size:10px;color:var(--muted)">Abonnés</div></div>
        <div style="text-align:center"><div style="font-size:15px;font-weight:500">${p.posts}</div><div style="font-size:10px;color:var(--muted)">Posts</div></div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="com-btn-p" style="flex:1">+ Nouveau post</button>
        <button class="com-btn-s">⚙️ Paramètres</button>
        <button class="com-btn-s">📊 Stats</button>
      </div>
    </div>
    <div style="padding:12px 16px;font-size:12px;font-weight:500;color:var(--muted);text-transform:uppercase;letter-spacing:.07em">Publications récentes</div>
    ${filPosts.slice(0,2).map(fp=>`<div class="post-card"><div style="font-size:32px;margin-bottom:8px">${fp.emoji}</div><div class="p-text">${fp.text}</div><div class="p-actions"><button class="p-act"><span class="p-act-icon">❤️</span>${fp.likes}</button><button class="p-act"><span class="p-act-icon">💬</span>${fp.comments}</button></div></div>`).join('')}
    <div style="height:80px"></div>`;
}

function renderGroupeDetail(g) {
  document.getElementById('gd-title').textContent=g.name;
  document.getElementById('groupe-detail-content').innerHTML=`
    <div style="height:100px;background:${g.cover};display:flex;align-items:center;justify-content:center;font-size:60px">${g.emoji}</div>
    <div style="background:var(--card);padding:14px 16px;border-bottom:1px solid var(--border)">
      <div style="font-size:17px;font-weight:500;color:var(--text);margin-bottom:3px">${g.name}</div>
      <div style="font-size:12px;color:var(--muted);margin-bottom:8px">${g.privacy} · ${g.members} membres · ${g.role}</div>
      <div style="display:flex;gap:8px">
        <button class="com-btn-p" style="flex:1">+ Publier dans le groupe</button>
        <button class="com-btn-s">👥 Membres</button>
        <button class="com-btn-s">⚙️</button>
      </div>
    </div>
    <div style="padding:12px 16px">
      <div style="background:var(--green-light);border-radius:12px;padding:12px 14px;margin-bottom:12px">
        <div style="font-size:12px;font-weight:500;color:var(--green-deep);margin-bottom:4px">📋 Règles du groupe</div>
        <div style="font-size:12px;color:var(--text)">Respectez-vous mutuellement. Partagez uniquement du contenu lié à la photographie. Pas de spam.</div>
      </div>
      <div style="font-size:12px;font-weight:500;color:var(--muted);text-transform:uppercase;letter-spacing:.07em;margin-bottom:10px">Publications récentes</div>
      ${filPosts.slice(0,3).map(fp=>`<div class="post-card"><div class="post-hd"><div class="p-av" style="background:${fp.user.color}">${fp.user.init}</div><div class="p-meta"><div class="p-name">${fp.user.name}</div><div class="p-time">il y a ${fp.time}</div></div></div><div class="p-text">${fp.text}</div><div class="p-actions"><button class="p-act"><span class="p-act-icon">❤️</span>${fp.likes}</button><button class="p-act"><span class="p-act-icon">💬</span>${fp.comments}</button></div></div>`).join('')}
    </div>
    <div style="height:80px"></div>`;
}

function openModal(type) {
  document.getElementById('modal-'+type).classList.add('open');
  resetModal(type);
  if(type==='groupe') renderInviteSuggestions();
}
function closeModal(type, evt) {
  if(evt && evt.target!==document.getElementById('modal-'+type)) return;
  document.getElementById('modal-'+type).classList.remove('open');
}
function resetModal(type) {
  const steps = document.querySelectorAll(`#modal-${type} .form-step`);
  steps.forEach((s,i)=>{s.classList.toggle('active',i===0);});
  updateStepDots(type,1);
  if(type==='page'){
    document.getElementById('page-name').value='';
    document.getElementById('page-desc').value='';
    document.getElementById('page-web').value='';
    document.getElementById('page-loc').value='Kigali, Rwanda';
    document.getElementById('page-cover-picker').innerHTML='<span style="font-size:28px">🖼️</span><span style="font-size:13px;color:var(--muted)">Ajouter une photo de couverture</span>';
    document.getElementById('page-cover-picker').classList.remove('cover-picked');
  }
  if(type==='groupe'){
    document.getElementById('groupe-name').value='';
    document.getElementById('groupe-desc').value='';
    document.getElementById('groupe-rules').value='';
    document.getElementById('groupe-cover-picker').innerHTML='<span style="font-size:28px">🖼️</span><span style="font-size:13px;color:var(--muted)">Ajouter une photo de couverture</span>';
    document.getElementById('groupe-cover-picker').classList.remove('cover-picked');
    invitedPeople=[];
    renderInvitedChips();
    selectedPrivacy='public';
    ['public','prive','secret'].forEach(p=>{const el=document.getElementById('pr-'+p);if(el){el.classList.toggle('selected',p==='public');el.querySelector('.privacy-check').textContent=p==='public'?'✓':'';} });
  }
}

function nextStep(type, step) {
  // Validation étape 1
  if(step===2 && type==='page'){
    const name=document.getElementById('page-name').value.trim();
    if(!name){document.getElementById('page-name').focus();document.getElementById('page-name').style.borderColor='var(--coral)';return;}
    document.getElementById('page-name').style.borderColor='';
  }
  if(step===2 && type==='groupe'){
    const name=document.getElementById('groupe-name').value.trim();
    if(!name){document.getElementById('groupe-name').focus();document.getElementById('groupe-name').style.borderColor='var(--coral)';return;}
    document.getElementById('groupe-name').style.borderColor='';
  }
  if(step===3 && type==='page') updatePagePreview();
  document.querySelectorAll(`#modal-${type} .form-step`).forEach(s=>s.classList.remove('active'));
  const target = document.getElementById(`${type}-step-${step}`) || document.getElementById(`${type}-step-success`);
  if(target) target.classList.add('active');
  updateStepDots(type, step);
}

function updateStepDots(type, step) {
  const dots = document.querySelectorAll(`#${type}-steps .step-dot`);
  dots.forEach((d,i)=>{
    d.classList.remove('done','active');
    if(i+1<step) d.classList.add('done');
    else if(i+1===step) d.classList.add('active');
  });
}

function updatePagePreview() {
  const name = document.getElementById('page-name').value.trim() || 'Nom de la page';
  const desc = document.getElementById('page-desc').value.trim() || 'Description de ta page…';
  const cat = document.querySelector('#page-cat-grid .selected')?.dataset?.cat || 'Catégorie';
  const loc = document.getElementById('page-loc').value.trim() || 'Localisation';
  document.getElementById('page-prev-name').textContent=name;
  document.getElementById('page-prev-desc').textContent=desc;
  document.getElementById('page-prev-cat').textContent=`${cat} · ${loc}`;
}

function pickCover(type) {
  const emojis = COVER_EMOJIS[type];
  const emoji = emojis[Math.floor(Math.random()*emojis.length)];
  const colors = ['linear-gradient(135deg,#085041,#1D9E75)','linear-gradient(135deg,#185FA5,#534AB7)','linear-gradient(135deg,#993556,#D85A30)','linear-gradient(135deg,#854F0B,#FAC775)'];
  const color = colors[Math.floor(Math.random()*colors.length)];
  const el = document.getElementById(`${type}-cover-picker`);
  el.style.background=color; el.style.height='90px';
  el.innerHTML=`<span style="font-size:44px">${emoji}</span><button class="cover-change" onclick="event.stopPropagation();pickCover('${type}')">🔄 Changer</button>`;
  el.classList.add('cover-picked');
  if(type==='page'){
    document.getElementById('page-prev-cover').style.background=color;
    document.getElementById('page-prev-cover').textContent=emoji;
  }
}

function selectCat(el, gridId) {
  document.querySelectorAll(`#${gridId} .cat-opt`).forEach(o=>o.classList.remove('selected'));
  el.classList.add('selected');
}

function selectPrivacy(val) {
  selectedPrivacy=val;
  ['public','prive','secret'].forEach(p=>{
    const el=document.getElementById('pr-'+p);
    if(el){el.classList.toggle('selected',p===val);el.querySelector('.privacy-check').textContent=p===val?'✓':'';}
  });
}

function renderInviteSuggestions() {
  document.getElementById('invite-suggestions').innerHTML = PEOPLE.map((p,i)=>`
    <div class="invite-person${invitedPeople.includes(i)?' invited':''}" id="ip-${i}" onclick="toggleInvite(${i})">
      <div class="inv-av" style="background:${p.color}">${p.init}</div>
      <div class="inv-name">${p.name}<div style="font-size:10px;color:var(--muted)">${p.handle}</div></div>
      <button class="inv-btn">${invitedPeople.includes(i)?'✓ Invité':'Inviter'}</button>
    </div>`).join('');
}

function toggleInvite(idx) {
  const i = invitedPeople.indexOf(idx);
  if(i===-1) invitedPeople.push(idx); else invitedPeople.splice(i,1);
  renderInvitedChips();
  renderInviteSuggestions();
}

function renderInvitedChips() {
  document.getElementById('invited-chips').innerHTML = invitedPeople.map(idx=>`
    <div class="invite-chip">
      <div class="invite-chip-av" style="background:${PEOPLE[idx].color}">${PEOPLE[idx].init}</div>
      <span class="invite-chip-name">${PEOPLE[idx].name.split(' ')[0]}</span>
      <button class="invite-chip-rm" onclick="toggleInvite(${idx})">×</button>
    </div>`).join('');
}

function createPage() {
  const name = document.getElementById('page-name').value.trim() || 'Ma nouvelle page';
  const desc = document.getElementById('page-desc').value.trim() || '';
  const cat = document.querySelector('#page-cat-grid .selected')?.dataset?.cat || 'Général';
  const coverEl = document.getElementById('page-cover-picker');
  const cover = coverEl.classList.contains('cover-picked') ? coverEl.style.background : 'linear-gradient(135deg,#085041,#1D9E75)';
  const emoji = coverEl.querySelector('span')?.textContent || '📄';
  myPages.push({name,cat:'📄 '+cat,loc:document.getElementById('page-loc').value||'Rwanda',desc,cover,emoji,followers:0,posts:0});
  document.querySelectorAll('#modal-page .form-step').forEach(s=>s.classList.remove('active'));
  document.getElementById('page-step-success').classList.add('active');
  document.querySelectorAll('#page-steps .step-dot').forEach(d=>d.classList.add('done'));
  renderCommunaute();
}

function createGroupe() {
  const name = document.getElementById('groupe-name').value.trim() || 'Mon nouveau groupe';
  const desc = document.getElementById('groupe-desc').value.trim() || '';
  const coverEl = document.getElementById('groupe-cover-picker');
  const cover = coverEl.classList.contains('cover-picked') ? coverEl.style.background : 'linear-gradient(135deg,#085041,#1D9E75)';
  const emoji = coverEl.querySelector('span')?.textContent || '👥';
  const privacyLabel = {public:'🌐 Public',prive:'🔒 Privé',secret:'👁️‍🗨️ Secret'}[selectedPrivacy];
  myGroupes.push({name,privacy:privacyLabel,cover,emoji,members:invitedPeople.length+1,posts:0,role:'Admin',desc});
  document.querySelectorAll('#modal-groupe .form-step').forEach(s=>s.classList.remove('active'));
  document.getElementById('groupe-step-success').classList.add('active');
  document.querySelectorAll('#groupe-steps .step-dot').forEach(d=>d.classList.add('done'));
  renderCommunaute();
}

function toggleComments(pid) {
  if(openComments.has(pid)) openComments.delete(pid);
  else openComments.add(pid);
  const cl = document.getElementById('cl-'+pid);
  const arrow = document.getElementById('ca-'+pid);
  if(cl) cl.style.display = openComments.has(pid) ? 'block' : 'none';
  if(arrow) arrow.classList.toggle('open', openComments.has(pid));
  if(openComments.has(pid)) {
    setTimeout(()=>{
      const inp = document.getElementById('cc-'+pid);
      if(inp) inp.scrollIntoView({behavior:'smooth', block:'nearest'});
    }, 100);
  }
}

function toggleCommentLike(pid, cid, isReply) {
  const comments = COMMENTS_DATA[pid] || [];
  let comment = null;
  if(isReply) {
    for(const c of comments) {
      comment = c.replies.find(r=>r.id===cid);
      if(comment) break;
    }
  } else {
    comment = comments.find(c=>c.id===cid);
  }
  if(!comment) return;
  comment.liked = !comment.liked;
  comment.likes += comment.liked ? 1 : -1;
  // Re-render just this comment item
  const el = document.getElementById('citem-'+cid);
  if(el) {
    const btn = el.querySelector('.c-action.liked, .c-action:first-child');
    if(btn) {
      btn.classList.toggle('liked', comment.liked);
      btn.innerHTML = `${comment.liked?'❤️':'🤍'} ${comment.likes>0?comment.likes:''}`;
    }
  }
}

function toggleReaction(pid, emoji) {
  const data = REACTIONS_DATA[pid];
  if(!data) return;
  const prev = userReactions[pid];
  if(prev === emoji) {
    // un-react
    data.emojis[emoji] = Math.max(0, (data.emojis[emoji]||1) - 1);
    userReactions[pid] = null;
  } else {
    if(prev && data.emojis[prev]) data.emojis[prev] = Math.max(0, data.emojis[prev] - 1);
    data.emojis[emoji] = (data.emojis[emoji]||0) + 1;
    userReactions[pid] = emoji;
  }
  // Re-render only reactions bar in this post
  const post = document.getElementById('post-'+pid);
  if(post) {
    const rb = post.querySelector('.reactions-bar');
    if(rb) rb.outerHTML = renderReactionsBar(pid);
    // Need to re-find since outerHTML replaces it
    const newRb = post.querySelector('.reactions-bar');
    if(newRb) newRb.outerHTML = renderReactionsBar(pid);
  }
  // Simpler: just update the bar HTML
  const postEl = document.getElementById('post-'+pid);
  if(postEl) {
    const allBars = postEl.querySelectorAll('.reactions-bar');
    if(allBars.length) allBars[0].innerHTML = Object.entries(data.emojis)
      .map(([e,n])=>`<button class="reaction-btn${userReactions[pid]===e?' active':''}" onclick="toggleReaction(${pid},'${e}')">${e}<span class="reaction-count">${n}</span></button>`)
      .join('');
  }
}

function startReply(pid, cid, name) {
  replyingTo = {postId:pid, commentId:cid, name};
  const ri = document.getElementById('ri-'+pid);
  if(ri) {
    ri.classList.add('show');
    ri.innerHTML = `<span class="reply-indicator-text">↩ Répondre à <b>${name}</b></span><button class="reply-cancel" onclick="cancelReply(${pid})">✕</button>`;
  }
  const inp = document.getElementById('cc-'+pid);
  if(inp) { inp.placeholder=`Répondre à ${name}…`; inp.focus(); }
}

function cancelReply(pid) {
  replyingTo = null;
  const ri = document.getElementById('ri-'+pid);
  if(ri) { ri.classList.remove('show'); ri.innerHTML=''; }
  const inp = document.getElementById('cc-'+pid);
  if(inp) inp.placeholder = 'Ajouter un commentaire…';
}

function submitComment(pid) {
  const inp = document.getElementById('cc-'+pid);
  const text = inp ? inp.value.trim() : '';
  if(!text) return;
  const newComment = {
    id: nextId++,
    user: {init:'KM', color:'#085041', name:'Keza Mutoni'},
    text,
    time: "à l'instant",
    likes: 0,
    liked: false,
    replies: []
  };
  if(!COMMENTS_DATA[pid]) COMMENTS_DATA[pid] = [];

  if(replyingTo && replyingTo.postId===pid) {
    // Add as reply
    const parent = COMMENTS_DATA[pid].find(c=>c.id===replyingTo.commentId);
    if(parent) {
      parent.replies.push(newComment);
      // Render new reply inside replies list
      const repliesList = document.getElementById('replies-'+replyingTo.commentId);
      if(repliesList) repliesList.insertAdjacentHTML('beforeend', renderComment(pid, newComment, true));
    }
    cancelReply(pid);
  } else {
    // Add as top-level comment
    COMMENTS_DATA[pid].unshift(newComment);
    const clist = document.getElementById('clist-'+pid);
    if(clist) clist.insertAdjacentHTML('afterbegin', renderComment(pid, newComment, false));
  }

  // Update comment count
  const total = COMMENTS_DATA[pid].reduce((a,c)=>a+1+c.replies.length,0);
  const ccEl = document.getElementById('ccount-'+pid);
  if(ccEl) ccEl.textContent = total;

  if(inp) { inp.value=''; inp.placeholder='Ajouter un commentaire…'; }
  const sendBtn = document.getElementById('cc-send-'+pid);
  if(sendBtn) sendBtn.disabled = true;
}

function showMoreComments(pid) {
  // Re-render all comments for this post (show all)
  openComments.add(pid);
  const clist = document.getElementById('clist-'+pid);
  if(clist) clist.innerHTML = (COMMENTS_DATA[pid]||[]).map(c=>renderComment(pid,c)).join('');
  // Remove show more button
  const btn = document.querySelector(`#cl-${pid} .show-more-comments`);
  if(btn) btn.remove();
}

const EMOJIS_QUICK = ['😊','🔥','💚','😍','🌺','👏','😂','✨','💪','🙏'];
function insertEmoji(pid) {
  const inp = document.getElementById('cc-'+pid);
  if(!inp) return;
  // Cycle through quick emojis
  const idx = Math.floor(Math.random()*EMOJIS_QUICK.length);
  inp.value += EMOJIS_QUICK[idx];
  inp.focus();
  const sendBtn = document.getElementById('cc-send-'+pid);
  if(sendBtn) sendBtn.disabled = false;
}

const LIVE_STREAMS = [
  {id:'l1',host:PEOPLE[0],title:'Séance photo — coucher de soleil 📸',emoji:'🌅',bg:'linear-gradient(135deg,#085041,#1D9E75)',viewers:1247,cat:'photo',peak:1890,msgs:342},
  {id:'l2',host:PEOPLE[2],title:'Cuisine africaine en direct 🍛',emoji:'🍛',bg:'linear-gradient(135deg,#854F0B,#D85A30)',viewers:538,cat:'food',peak:610,msgs:189},
  {id:'l3',host:PEOPLE[1],title:'Session beatmaking 🎵',emoji:'🎵',bg:'linear-gradient(135deg,#185FA5,#534AB7)',viewers:324,cat:'musique',peak:410,msgs:97},
  {id:'l4',host:PEOPLE[3],title:'Actu Rwanda live 📰',emoji:'📰',bg:'linear-gradient(135deg,#2C2C2A,#5F5E5A)',viewers:892,cat:'actu',peak:950,msgs:456},
];

const LIVE_MSGS_POOL = [
  "Superbe ! 🔥","On t'adore 💚","Continue comme ça !","Bonjour depuis Dakar 👋","Tu es incroyable 😍",
  "On veut plus ! 🙌","Kigali représente ! 🇷🇼","La qualité est top","Magnifique shot 📸","Tu inspires beaucoup 💫",
  "Nouvelle abonnée ici ✨","Bao forever 💚","Bravo chef ! 🍛","La sauce sent bon 😂","Partage la recette !",
];

let liveState = {
  active: false,
  isHost: false,
  stream: null,
  viewers: 0,
  peakViewers: 0,
  totalMsgs: 0,
  totalReacts: 0,
  reactions: {'❤️':0,'🔥':0,'😍':0,'👏':0,'🎉':0},
  timerRef: null,
  autoMsgRef: null,
  viewerGrowRef: null,
  seconds: 0,
  micOn: true,
  camOn: true,
};

function renderLiveList(cat='tout') {
  const filtered = cat==='tout' ? LIVE_STREAMS : LIVE_STREAMS.filter(l=>l.cat===cat);
  document.getElementById('live-list').innerHTML = filtered.map(l=>`
    <div class="live-entry-card" onclick="openLiveRoom(false,'${l.id}')">
      <div class="lec-thumb" style="background:${l.bg}">
        <span style="font-size:52px">${l.emoji}</span>
        <div class="lec-badge"><span class="lec-dot"></span>DIRECT</div>
        <div class="lec-viewers">👁 ${l.viewers.toLocaleString('fr-FR')}</div>
      </div>
      <div class="lec-body">
        <div class="lec-host">
          <div class="lec-av" style="background:${l.host.color}">${l.host.init}</div>
          <span class="lec-name">${l.host.name}</span>
        </div>
        <div class="lec-title">${l.title}</div>
        <button class="lec-join-btn">🔴 Rejoindre le live</button>
      </div>
    </div>`).join('');
}

function filterLiveCat(el, cat) {
  document.querySelectorAll('.live-cat').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');
  renderLiveList(cat);
}

function openLiveRoom(isHost, streamId) {
  const stream = streamId ? LIVE_STREAMS.find(l=>l.id===streamId) : null;
  liveState.isHost = isHost;
  liveState.stream = stream;
  liveState.active = true;
  liveState.seconds = 0;
  liveState.totalMsgs = 0;
  liveState.totalReacts = 0;
  liveState.reactions = {'❤️':0,'🔥':0,'😍':0,'👏':0,'🎉':0};
  liveState.viewers = stream ? stream.viewers : 1;
  liveState.peakViewers = liveState.viewers;

  // Set bg
  const bg = stream ? stream.bg : 'linear-gradient(135deg,#085041,#1D9E75)';
  const emoji = stream ? stream.emoji : '📡';
  const vArea = document.querySelector('.live-video-area');
  if(vArea) vArea.style.background = bg;
  document.getElementById('lr-bg-emoji').textContent = emoji;

  // Host info
  const host = stream ? stream.host : {init:'KM',color:'#085041',name:'Keza Mutoni'};
  document.getElementById('lr-host-av').style.background = host.color;
  document.getElementById('lr-host-av').textContent = host.init;
  document.getElementById('lr-host-name').textContent = host.name;

  // Show/hide host controls
  document.getElementById('host-bar').style.display = isHost ? 'flex' : 'none';

  // Clear chat
  document.getElementById('lr-chat').innerHTML = '';
  document.getElementById('float-zone').innerHTML = '';
  document.getElementById('live-end-overlay').classList.remove('show');

  // Reset reaction counts
  Object.keys(liveState.reactions).forEach(e=>{
    const el=document.getElementById('rc-'+e.codePointAt(0));
    if(el) el.textContent='0';
  });

  // Build viewers strip
  renderViewersStrip();

  // Show screen
  document.getElementById('screen-live-room').classList.add('active');

  // Start timer
  liveState.timerRef = setInterval(updateLiveTimer, 1000);

  // Auto messages
  addLiveSysMsg(isHost ? '🔴 Live démarré ! Tes abonnés arrivent…' : `👋 Tu as rejoint le live de ${host.name}`);
  liveState.autoMsgRef = setInterval(()=>{
    const user = PEOPLE[Math.floor(Math.random()*PEOPLE.length)];
    const msg = LIVE_MSGS_POOL[Math.floor(Math.random()*LIVE_MSGS_POOL.length)];
    addLiveChatMsg(user, msg);
    liveState.totalMsgs++;
  }, isHost ? 2200 : 3000);

  // Viewer growth
  liveState.viewerGrowRef = setInterval(()=>{
    const delta = Math.floor(Math.random()*12) - 3;
    liveState.viewers = Math.max(1, liveState.viewers + delta);
    liveState.peakViewers = Math.max(liveState.peakViewers, liveState.viewers);
    document.getElementById('lr-viewers').textContent = liveState.viewers.toLocaleString('fr-FR');
    if(Math.random() > 0.6) renderViewersStrip();
    // Random auto-reaction
    if(Math.random() > 0.7) {
      const emojis = Object.keys(liveState.reactions);
      autoReaction(emojis[Math.floor(Math.random()*emojis.length)]);
    }
  }, 2500);

  // Random gift/event every 15s
  if(isHost) {
    setTimeout(function liveEvent(){
      if(!liveState.active) return;
      const events = ['🎁 Cadeau reçu de Amina !','⭐ Nouveau super abonné !','📣 Partage de Kweku !'];
      addLiveSysMsg(events[Math.floor(Math.random()*events.length)]);
      setTimeout(liveEvent, 12000 + Math.random()*8000);
    }, 10000);
  }
}

function renderViewersStrip() {
  const strip = document.getElementById('lr-viewers-strip');
  const count = Math.min(5, Math.floor(liveState.viewers/200)+2);
  strip.innerHTML = PEOPLE.slice(0,count).map(p=>`
    <div class="lv-av" style="background:${p.color}">${p.init}</div>`).join('') +
    (liveState.viewers>500 ? `<div class="lv-av lv-more">+${Math.floor((liveState.viewers-100)/100)*100}</div>` : '');
}

function updateLiveTimer() {
  liveState.seconds++;
  const m = String(Math.floor(liveState.seconds/60)).padStart(2,'0');
  const s = String(liveState.seconds%60).padStart(2,'0');
  const el = document.getElementById('lr-duration');
  if(el) el.textContent = m+':'+s;
}

function addLiveChatMsg(user, text) {
  const chat = document.getElementById('lr-chat');
  if(!chat) return;
  const div = document.createElement('div');
  div.className='lcm';
  div.innerHTML=`<div class="lcm-av" style="background:${user.color}">${user.init}</div><div class="lcm-bubble"><div class="lcm-name">${user.name.split(' ')[0]}</div><div class="lcm-text">${text}</div></div>`;
  chat.appendChild(div);
  // Keep only last 5 messages visible
  while(chat.children.length > 5) chat.removeChild(chat.firstChild);
}

function addLiveSysMsg(text) {
  const chat = document.getElementById('lr-chat');
  if(!chat) return;
  const div = document.createElement('div');
  div.className='lcm';
  div.innerHTML=`<div class="lcm-bubble" style="background:rgba(250,199,117,.2);"><div class="lcm-text" style="color:var(--sand);font-weight:500;">${text}</div></div>`;
  chat.appendChild(div);
  while(chat.children.length > 5) chat.removeChild(chat.firstChild);
}

function sendLiveMsg() {
  const inp = document.getElementById('lr-inp');
  const text = inp ? inp.value.trim() : '';
  if(!text) return;
  addLiveChatMsg({init:'KM',color:'#085041',name:'Keza Mutoni'},text);
  liveState.totalMsgs++;
  inp.value = '';
}

function sendReaction(emoji) {
  liveState.reactions[emoji] = (liveState.reactions[emoji]||0)+1;
  liveState.totalReacts++;
  const el = document.getElementById('rc-'+emoji.codePointAt(0));
  if(el) el.textContent = formatReactCount(liveState.reactions[emoji]);
  spawnFloat(emoji, false);
}

function autoReaction(emoji) {
  liveState.reactions[emoji] = (liveState.reactions[emoji]||0)+1;
  const el = document.getElementById('rc-'+emoji.codePointAt(0));
  if(el) el.textContent = formatReactCount(liveState.reactions[emoji]);
  spawnFloat(emoji, true);
}

function spawnFloat(emoji, auto) {
  const zone = document.getElementById('float-zone');
  if(!zone) return;
  const div = document.createElement('div');
  div.className='float-r';
  div.textContent = emoji;
  div.style.right = (Math.random()*30)+'px';
  zone.appendChild(div);
  setTimeout(()=>div.remove(), 2900);
}

function formatReactCount(n) {
  if(n >= 1000) return (n/1000).toFixed(1)+'k';
  return n;
}

function toggleHostCtrl(type, btn) {
  if(type==='mic') {
    liveState.micOn = !liveState.micOn;
    btn.textContent = liveState.micOn ? '🎙️ Micro ON' : '🔇 Micro OFF';
    btn.classList.toggle('muted', !liveState.micOn);
  } else if(type==='cam') {
    liveState.camOn = !liveState.camOn;
    btn.textContent = liveState.camOn ? '📹 Caméra' : '📵 Caméra OFF';
    btn.classList.toggle('active', !liveState.camOn);
  } else if(type==='screen') {
    btn.classList.toggle('active');
    addLiveSysMsg(btn.classList.contains('active') ? '🖥️ Partage d\'écran activé' : '🖥️ Partage d\'écran arrêté');
  } else if(type==='poll') {
    showLivePoll();
  }
}

function showLivePoll() {
  const poll = document.getElementById('live-poll');
  if(!poll) return;
  const options = [
    {label:'🌅 Photo extérieure',votes:Math.floor(Math.random()*100+20)},
    {label:'📸 Portrait studio',votes:Math.floor(Math.random()*80+10)},
    {label:'🌃 Photo de nuit',votes:Math.floor(Math.random()*60+5)},
  ];
  const total = options.reduce((a,b)=>a+b.votes,0);
  document.getElementById('poll-options').innerHTML = options.map(o=>`
    <div style="margin-bottom:8px;cursor:pointer;" onclick="votePoll(this,${o.votes},${total})">
      <div style="display:flex;justify-content:space-between;margin-bottom:3px;">
        <span style="font-size:11px;color:#fff;">${o.label}</span>
        <span style="font-size:11px;color:rgba(255,255,255,.7);">${Math.round(o.votes/total*100)}%</span>
      </div>
      <div style="height:6px;background:rgba(255,255,255,.2);border-radius:6px;overflow:hidden;">
        <div style="height:100%;width:${Math.round(o.votes/total*100)}%;background:var(--sand);border-radius:6px;transition:width .4s;"></div>
      </div>
    </div>`).join('');
  poll.style.display = poll.style.display==='none' ? 'block' : 'none';
}

function votePoll(el, votes, total) {
  const bar = el.querySelector('div div div');
  const newVotes = votes + 1;
  const newTotal = total + 1;
  if(bar) bar.style.width = Math.round(newVotes/newTotal*100)+'%';
  el.querySelector('span:last-child').textContent = Math.round(newVotes/newTotal*100)+'%';
  addLiveSysMsg('✅ Vote enregistré !');
}

function endLive() {
  clearInterval(liveState.timerRef);
  clearInterval(liveState.autoMsgRef);
  clearInterval(liveState.viewerGrowRef);
  liveState.active = false;
  // Show end stats
  document.getElementById('leo-peak').textContent = liveState.peakViewers.toLocaleString('fr-FR');
  document.getElementById('leo-msgs').textContent = liveState.totalMsgs;
  document.getElementById('leo-reacts').textContent = liveState.totalReacts;
  document.getElementById('live-end-overlay').classList.add('show');
}

function closeLiveRoom() {
  clearInterval(liveState.timerRef);
  clearInterval(liveState.autoMsgRef);
  clearInterval(liveState.viewerGrowRef);
  liveState.active = false;
  document.getElementById('screen-live-room').classList.remove('active');
  document.getElementById('live-end-overlay').classList.remove('show');
  document.getElementById('live-poll').style.display = 'none';
}

// Fake users DB in localStorage
function getUsers() {
  try { return JSON.parse(localStorage.getItem('lifebao_users')||'[]'); } catch(e){return [];}
}
function saveUsers(users) {
  localStorage.setItem('lifebao_users', JSON.stringify(users));
}
function getSession() {
  try { return JSON.parse(localStorage.getItem('lifebao_session')||'null'); } catch(e){return null;}
}
function saveSession(user) {
  localStorage.setItem('lifebao_session', JSON.stringify(user));
}
function clearSession() {
  localStorage.removeItem('lifebao_session');
}

// Seed demo account
(function seedDemo(){
  const users = getUsers();
  if(!users.find(u=>u.email==='keza@lifebao.rw')){
    users.push({
      email:'keza@lifebao.rw', handle:'keza.bao',
      firstname:'Keza', lastname:'Mutoni',
      password:'lifebao123', avatar:'🌺',
      location:'Kigali, Rwanda', bio:'Photographe 📸 | Kigali 🌺',
      interests:['Photographie','Voyages','Art & Design'],
      createdAt: new Date().toISOString()
    });
    saveUsers(users);
  }
})();

let selectedAvatar = '🌺';
let signupStep = 1;
let selectedInterests = [];
let currentUser = null;

// ── INIT AUTH ───────────────────────────────
function initAuth() {
  const session = getSession();
  if(session) {
    currentUser = session;
    enterApp(true); // silent entry
  } else {
    document.getElementById('auth-overlay').classList.remove('hidden');
  }
}

function enterApp(silent=false) {
  const overlay = document.getElementById('auth-overlay');
  if(!silent) {
    overlay.style.transition = 'opacity .4s ease';
    overlay.style.opacity = '0';
    setTimeout(()=>{ overlay.classList.add('hidden'); overlay.style.opacity=''; overlay.style.transition=''; }, 400);
  } else {
    overlay.classList.add('hidden');
  }
  // Update UI with user data
  if(currentUser) updateAppWithUser(currentUser);
}

function updateAppWithUser(user) {
  // Update all avatar initials
  const initials = (user.firstname[0]+(user.lastname||'')[0]||'').toUpperCase();
  document.querySelectorAll('.av-btn,.av-sm,.c-av,.cc-av,.prof-av,.sett-av').forEach(el=>{
    if(el.textContent.trim()==='KM') el.textContent = initials;
  });
  // Update profile name
  const profName = document.querySelector('.prof-name');
  if(profName) profName.textContent = user.firstname+' '+(user.lastname||'');
  const profHandle = document.querySelector('.prof-handle');
  if(profHandle) profHandle.innerHTML = `@${user.handle} · <span style="color:var(--green-mid);font-size:11px">✓ Bao vérifié</span>`;
  const profBio = document.querySelector('.prof-bio');
  if(profBio && user.bio) profBio.textContent = user.bio;
  // Update avatar display
  document.getElementById('auth-av-preview').textContent = user.avatar||'🌺';
}

// ── TAB SWITCHING ────────────────────────────
function switchAuthTab(tab) {
  ['login','signup','forgot','welcome'].forEach(t=>{
    const form = document.getElementById('form-'+t);
    const tabEl = document.getElementById('tab-'+t);
    if(form) form.classList.toggle('active', t===tab);
    if(tabEl) tabEl.classList.toggle('active', t===tab);
  });
  clearAlerts();
}

function showForgot() {
  ['login','signup','forgot','welcome'].forEach(t=>{
    const form = document.getElementById('form-'+t);
    const tabEl = document.getElementById('tab-'+t);
    if(form) form.classList.toggle('active', t==='forgot');
    if(tabEl) tabEl.classList.remove('active');
  });
}

function clearAlerts() {
  document.querySelectorAll('.auth-alert').forEach(a=>{a.classList.remove('show','error','success');a.textContent='';});
}

function showAlert(id, msg, type='error') {
  const el = document.getElementById(id);
  if(!el) return;
  el.textContent = msg;
  el.className = `auth-alert ${type} show`;
}

// ── LOGIN ────────────────────────────────────
function submitLogin() {
  const email = document.getElementById('login-email').value.trim().toLowerCase();
  const pw    = document.getElementById('login-pw').value;
  const btn   = document.getElementById('login-btn');

  clearAlerts();

  if(!email){ showAlert('login-alert','📧 Entre ton email ou pseudo.'); return; }
  if(!pw){ showAlert('login-alert','🔒 Entre ton mot de passe.'); return; }

  btn.disabled = true;
  btn.innerHTML = '<span class="spin">⏳</span> Connexion…';

  setTimeout(()=>{
    const users = getUsers();
    const user = users.find(u=>
      (u.email===email || u.handle===email || ('@'+u.handle)===email) &&
      u.password === pw
    );

    if(!user) {
      showAlert('login-alert','❌ Email ou mot de passe incorrect. Essaie avec keza@lifebao.rw / lifebao123');
      btn.disabled = false;
      btn.textContent = 'Se connecter';
      document.getElementById('login-pw').classList.add('error');
      setTimeout(()=>document.getElementById('login-pw').classList.remove('error'),2000);
      return;
    }

    currentUser = user;
    saveSession(user);
    btn.innerHTML = '✅ Connecté !';
    btn.style.background = '#1D9E75';
    setTimeout(()=>enterApp(), 600);
  }, 900);
}

// ── SOCIAL LOGIN (simulé) ────────────────────
function socialLogin(provider) {
  const icons = {Google:'Google',Facebook:'Facebook',Apple:'Apple'};
  // Simulate OAuth flow
  const fakeUser = {
    email: `user.${Date.now()}@${provider.toLowerCase()}.com`,
    handle: 'bao_'+Math.random().toString(36).substr(2,6),
    firstname: provider==='Google'?'Nadia':provider==='Facebook'?'Kwame':'Ama',
    lastname: 'Bao',
    password: '',
    avatar: ['🌺','🦁','🥭','☀️'][Math.floor(Math.random()*4)],
    location: 'Afrique', bio: `Connecté via ${provider} 🌍`,
    interests: ['Photographie','Voyages'],
    createdAt: new Date().toISOString(),
    provider
  };
  const users = getUsers();
  users.push(fakeUser);
  saveUsers(users);
  currentUser = fakeUser;
  saveSession(fakeUser);

  // Show brief success
  showAlert('login-alert', `${icons[provider]} Connexion ${provider} réussie ! Bienvenue ${fakeUser.firstname} 🎉`, 'success');
  setTimeout(()=>enterApp(), 1200);
}

// ── SIGNUP ───────────────────────────────────
function nextSignupStep(step) {
  // Validate current step
  if(step===2) {
    const fn = document.getElementById('su-firstname').value.trim();
    const ln = document.getElementById('su-lastname').value.trim();
    const em = document.getElementById('su-email').value.trim();
    const pw = document.getElementById('su-pw').value;
    if(!fn){ showAlert('signup-alert','✏️ Entre ton prénom.'); return; }
    if(!em || !em.includes('@')){ showAlert('signup-alert','📧 Entre un email valide.'); return; }
    if(pw.length<8){ showAlert('signup-alert','🔒 Mot de passe trop court (min. 8 caractères).'); return; }
    const users = getUsers();
    if(users.find(u=>u.email===em.toLowerCase())){ showAlert('signup-alert','📧 Cet email est déjà utilisé.'); return; }
    clearAlerts();
  }
  if(step===3) {
    const handle = document.getElementById('su-handle').value.trim().replace('@','');
    if(!handle || handle.length<3){ showAlert('signup-alert','@ Pseudo trop court (min. 3 caractères).'); return; }
    const users = getUsers();
    if(users.find(u=>u.handle===handle)){ showAlert('signup-alert','@ Ce pseudo est déjà pris. Essaie autre chose.'); return; }
    clearAlerts();
  }

  signupStep = step;
  document.querySelectorAll('.auth-step').forEach((s,i)=>s.classList.toggle('active',i+1===step));

  // Update progress dots
  [1,2,3].forEach(i=>{
    const dot = document.getElementById('prog-'+i);
    if(dot) dot.classList.toggle('done', i<=step);
  });
}

function submitSignup() {
  const interests = [...document.querySelectorAll('.interest-chip.picked')].map(el=>el.textContent.trim().split(' ').slice(1).join(' '));
  if(interests.length < 3){ showAlert('signup-alert','🎯 Sélectionne au moins 3 centres d\'intérêt.'); return; }

  const btn = document.getElementById('signup-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spin">⏳</span> Création du compte…';

  setTimeout(()=>{
    const user = {
      email: document.getElementById('su-email').value.trim().toLowerCase(),
      handle: document.getElementById('su-handle').value.trim().replace('@','').toLowerCase(),
      firstname: document.getElementById('su-firstname').value.trim(),
      lastname: document.getElementById('su-lastname').value.trim(),
      password: document.getElementById('su-pw').value,
      avatar: selectedAvatar,
      location: document.getElementById('su-location').value.trim() || 'Afrique',
      bio: document.getElementById('su-bio').value.trim(),
      interests,
      createdAt: new Date().toISOString()
    };

    const users = getUsers();
    users.push(user);
    saveUsers(users);
    currentUser = user;
    saveSession(user);

    // Show welcome
    document.getElementById('welcome-emoji').textContent = user.avatar;
    document.getElementById('auth-av-preview').textContent = user.avatar;
    document.getElementById('welcome-name').textContent = `${user.firstname}, bienvenue dans la famille Bao !`;
    switchAuthTab('welcome');
    // Update auth header avatar preview
    document.getElementById('auth-av-preview').textContent = user.avatar;

    btn.disabled = false;
    btn.textContent = '🚀 Créer mon compte';
  }, 1200);
}

// ── FORGOT ───────────────────────────────────
function submitForgot() {
  const email = document.getElementById('forgot-email').value.trim();
  if(!email || !email.includes('@')){ showAlert('forgot-alert','📧 Entre un email valide.'); return; }
  showAlert('forgot-alert', `✅ Si cet email existe, tu recevras un lien dans quelques minutes. Vérifie aussi tes spams.`, 'success');
}

// ── HELPERS ──────────────────────────────────
function togglePwVis(inputId, btn) {
  const inp = document.getElementById(inputId);
  if(!inp) return;
  const isText = inp.type==='text';
  inp.type = isText ? 'password' : 'text';
  btn.textContent = isText ? '👁️' : '🙈';
}

function checkPwStrength(pw) {
  const bar = document.getElementById('pw-bar');
  const lbl = document.getElementById('pw-label');
  if(!bar||!lbl) return;
  let score = 0;
  if(pw.length>=8) score++;
  if(pw.length>=12) score++;
  if(/[A-Z]/.test(pw)) score++;
  if(/[0-9]/.test(pw)) score++;
  if(/[^A-Za-z0-9]/.test(pw)) score++;
  const levels = [
    {w:'0%',   bg:'#e8f0ed', txt:''},
    {w:'20%',  bg:'#D85A30', txt:'Très faible'},
    {w:'40%',  bg:'#E8A030', txt:'Faible'},
    {w:'60%',  bg:'#FAC775', txt:'Moyen'},
    {w:'80%',  bg:'#1D9E75', txt:'Fort'},
    {w:'100%', bg:'#085041', txt:'Très fort 💪'},
  ];
  const lvl = levels[score] || levels[0];
  bar.style.width = lvl.w;
  bar.style.background = lvl.bg;
  lbl.textContent = lvl.txt;
  lbl.style.color = lvl.bg;
}

let handleCheckTimer;
function checkHandle(val) {
  const lbl = document.getElementById('handle-label');
  if(!lbl) return;
  clearTimeout(handleCheckTimer);
  val = val.replace(/[^a-z0-9_.]/gi,'').toLowerCase();
  document.getElementById('su-handle').value = val;
  if(val.length<3){ lbl.textContent='Min. 3 caractères'; lbl.style.color='var(--muted)'; return; }
  lbl.textContent='Vérification…'; lbl.style.color='var(--muted)';
  handleCheckTimer = setTimeout(()=>{
    const users = getUsers();
    const taken = users.find(u=>u.handle===val);
    if(taken){
      lbl.textContent='❌ Pseudo déjà pris';
      lbl.style.color='var(--coral,#D85A30)';
    } else {
      lbl.textContent='✅ @'+val+' est disponible !';
      lbl.style.color='#1D9E75';
    }
  }, 500);
}

function pickAvatar(el, emoji) {
  document.querySelectorAll('.av-pick').forEach(a=>a.classList.remove('selected'));
  el.classList.add('selected');
  selectedAvatar = emoji;
  const prev = document.getElementById('auth-av-preview');
  if(prev) {
    prev.style.transform = 'scale(0.8)';
    prev.textContent = emoji;
    setTimeout(()=>{ prev.style.transform = 'scale(1)'; }, 150);
  }
}

function toggleInterest(el) {
  el.classList.toggle('picked');
  // Vibration feedback on mobile
  if(navigator.vibrate) navigator.vibrate(30);
  // Count check
  const count = document.querySelectorAll('.interest-chip.picked').length;
  const alertEl = document.getElementById('signup-alert');
  if(count >= 3 && alertEl) alertEl.classList.remove('show');
  // Update counter display
  const counterEl = document.getElementById('interest-counter');
  if(counterEl) counterEl.textContent = count + ' / 14';
  const btn = document.getElementById('signup-btn');
  if(btn) {
    if(count >= 3) {
      btn.style.opacity = '1';
      btn.textContent = `🚀 Créer mon compte (${count} intérêts)`;
    } else {
      btn.style.opacity = '0.6';
      btn.textContent = `Sélectionne encore ${3-count} intérêt${3-count>1?'s':''}`;
    }
  }
}

// ── LOGOUT (depuis paramètres) ───────────────
function logout() {
  clearSession();
  currentUser = null;
  // Reset auth forms
  switchAuthTab('login');
  document.getElementById('login-email').value='';
  document.getElementById('login-pw').value='';
  clearAlerts();
  // Show auth overlay
  const overlay = document.getElementById('auth-overlay');
  overlay.classList.remove('hidden');
  overlay.style.opacity='0';
  requestAnimationFrame(()=>{overlay.style.transition='opacity .3s';overlay.style.opacity='1';setTimeout(()=>overlay.style.transition='',300);});
}

let activeDashTab = 'vue-ensemble';

// Generate realistic data based on period
function genData(days, base, variance, trend=1) {
  const arr = [];
  for(let i=0;i<days;i++){
    const t = trend===1 ? 1 + (i/days)*0.4 : 1 - (i/days)*0.2;
    arr.push(Math.max(0, Math.round((base + (Math.random()-0.5)*variance*2) * t)));
  }
  return arr;
}

function getDashPeriod() { return parseInt(document.getElementById('dash-period')?.value||28); }

function dashStats(period) {
  const m = period===7?1:period===28?4:period===90?12:52;
  return {
    followers:    { val:4812,  delta:+12.4, unit:'' },
    impressions:  { val:Math.round(18400*m/4), delta:+8.2,  unit:'' },
    engagement:   { val:6.8,  delta:+1.1,  unit:'%' },
    reach:        { val:Math.round(9200*m/4),  delta:+5.7,  unit:'' },
    likes:        { val:Math.round(2340*m/4),  delta:+18.3, unit:'' },
    comments:     { val:Math.round(487*m/4),   delta:-3.2,  unit:'' },
    shares:       { val:Math.round(312*m/4),   delta:+22.1, unit:'' },
    saves:        { val:Math.round(189*m/4),   delta:+9.4,  unit:'' },
    profileViews: { val:Math.round(1240*m/4),  delta:+31.7, unit:'' },
    linkClicks:   { val:Math.round(87*m/4),    delta:-5.8,  unit:'' },
  };
}

function fmtNum(n) {
  if(n>=1000000) return (n/1000000).toFixed(1)+'M';
  if(n>=1000) return (n/1000).toFixed(1)+'k';
  return n.toString();
}

function renderDashboard() {
  const period = getDashPeriod();
  const stats = dashStats(period);

  // Summary bar
  document.getElementById('dash-summary').innerHTML = [
    {l:'Abonnés',    n:fmtNum(stats.followers.val),    d:'+'+stats.followers.delta+'%'},
    {l:'Impressions',n:fmtNum(stats.impressions.val),  d:'+'+stats.impressions.delta+'%'},
    {l:'Engagement', n:stats.engagement.val+'%',       d:'+'+stats.engagement.delta+'pts'},
    {l:'Portée',     n:fmtNum(stats.reach.val),        d:'+'+stats.reach.delta+'%'},
  ].map(s=>`<div class="dash-sum-stat">
    <div class="dash-sum-n">${s.n}</div>
    <div class="dash-sum-l">${s.l}</div>
    <div class="dash-sum-delta up">${s.d}</div>
  </div>`).join('');

  renderDashTab(activeDashTab, period, stats);
}

function switchDashTab(el, tab) {
  document.querySelectorAll('.dash-tab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  activeDashTab = tab;
  renderDashboard();
}

function renderDashTab(tab, period, stats) {
  const c = document.getElementById('dash-content');
  if(tab==='vue-ensemble')  c.innerHTML = renderOverview(period, stats);
  if(tab==='contenu')       c.innerHTML = renderContent(period, stats);
  if(tab==='audience')      c.innerHTML = renderAudience(period, stats);
  if(tab==='revenus')       c.innerHTML = renderRevenu(period, stats);
  // Draw SVG charts after HTML is set
  setTimeout(()=>drawCharts(tab, period), 50);
}

// ── VUE D'ENSEMBLE ──────────────────────────
function renderOverview(period, stats) {
  return `
  <div class="kpi-grid">
    ${[
      {icon:'❤️', val:fmtNum(stats.likes.val),    label:'J\'aime',    delta:stats.likes.delta,    up:true},
      {icon:'💬', val:fmtNum(stats.comments.val), label:'Commentaires',delta:stats.comments.delta, up:stats.comments.delta>0},
      {icon:'🔁', val:fmtNum(stats.shares.val),   label:'Partages',   delta:stats.shares.delta,   up:true},
      {icon:'🔖', val:fmtNum(stats.saves.val),    label:'Sauvegardes',delta:stats.saves.delta,    up:true},
    ].map(k=>`
      <div class="kpi-card">
        <div class="kpi-icon">${k.icon}</div>
        <div class="kpi-val">${k.val}</div>
        <div class="kpi-label">${k.label}</div>
        <div class="kpi-delta ${k.up?'up':'down'}">${k.up?'↑':'↓'} ${Math.abs(k.delta)}%</div>
      </div>`).join('')}
  </div>

  <div class="chart-wrap">
    <div class="chart-title">
      Croissance des abonnés
      <div class="chart-legend">
        <div class="chart-leg-item"><div class="chart-leg-dot" style="background:#1D9E75"></div>Abonnés</div>
        <div class="chart-leg-item"><div class="chart-leg-dot" style="background:#FAC775"></div>Nouveaux</div>
      </div>
    </div>
    <svg class="chart-svg" height="120" id="chart-followers"></svg>
    <div class="hm-labels"><span class="hm-label">J1</span><span class="hm-label">J${Math.round(period/2)}</span><span class="hm-label">J${period}</span></div>
  </div>

  <div class="chart-wrap">
    <div class="chart-title">Impressions & Portée</div>
    <svg class="chart-svg" height="100" id="chart-reach"></svg>
    <div class="hm-labels"><span class="hm-label">J1</span><span class="hm-label">J${period}</span></div>
  </div>

  <div class="dash-section">
    <div class="dash-sec-title">💡 Conseils personnalisés</div>
    <div class="tip-card">
      <div class="tip-icon">🌅</div>
      <div class="tip-text"><div class="tip-title">Poste entre 18h et 20h</div>Ton audience est la plus active en soirée. Tes posts reçoivent 43% plus d'engagement à cette heure.</div>
    </div>
    <div class="tip-card" style="background:linear-gradient(135deg,#185FA5,#534AB7)">
      <div class="tip-icon">📸</div>
      <div class="tip-text"><div class="tip-title">Les photos performent mieux</div>Tes posts avec photos obtiennent 2.4× plus de portée que les posts texte seuls.</div>
    </div>
    <div class="tip-card" style="background:linear-gradient(135deg,#854F0B,#D85A30)">
      <div class="tip-icon">🏷️</div>
      <div class="tip-text"><div class="tip-title">Utilise 3-5 hashtags</div>#KigaliVibe et #LifeBao te donnent le meilleur reach. Évite les hashtags trop génériques.</div>
    </div>
  </div>

  <button class="dash-export-btn" onclick="exportStats()">📥 Exporter le rapport PDF</button>
  <div style="height:80px"></div>`;
}

// ── CONTENU ──────────────────────────────────
function renderContent(period, stats) {
  const posts = [
    {emoji:'🌅', text:'Coucher de soleil Rebero… #KigaliVibe', likes:1240, comments:48, reach:8420, saved:89, type:'Photo'},
    {emoji:'🍛', text:'Jollof rice officiel 🤌 #AfrikaFood', likes:987, comments:102, reach:6230, saved:124, type:'Photo'},
    {emoji:'🌍', text:'Life Bao connecte l\'Afrique 💚 #LifeBao', likes:756, comments:31, reach:5180, saved:67, type:'Texte'},
    {emoji:'📸', text:'Séance photo Kigali — portfolio 🎞️', likes:634, comments:24, reach:4320, saved:98, type:'Carrousel'},
    {emoji:'🎬', text:'Mon processus créatif en vidéo ✨', likes:512, comments:19, reach:3890, saved:45, type:'Vidéo'},
  ];
  const maxReach = Math.max(...posts.map(p=>p.reach));
  return `
  <div class="dash-section">
    <div class="dash-sec-title">Types de contenu <span class="dash-sec-hint">Voir tout</span></div>
    <div class="chart-wrap">
      <div class="chart-title">Engagement par type</div>
      ${[
        {type:'📸 Photo',    pct:68, color:'#1D9E75'},
        {type:'🎬 Vidéo',    pct:18, color:'#185FA5'},
        {type:'📝 Texte',    pct:9,  color:'#FAC775'},
        {type:'🔁 Carrousel',pct:5,  color:'#D85A30'},
      ].map(t=>`
        <div class="aud-row" style="margin-bottom:8px;">
          <div class="aud-label" style="width:90px;font-size:11px;color:var(--text)">${t.type}</div>
          <div class="aud-bar-bg"><div class="aud-bar-fill" style="width:${t.pct}%;background:${t.color}"></div></div>
          <div class="aud-pct">${t.pct}%</div>
        </div>`).join('')}
    </div>
  </div>

  <div class="dash-section">
    <div class="dash-sec-title">🏆 Posts les plus performants</div>
    <div class="chart-wrap" style="padding:12px 14px;">
      ${posts.map((p,i)=>`
        <div class="top-post-item">
          <div class="tp-rank">${['🥇','🥈','🥉','4','5'][i]}</div>
          <div class="tp-thumb">${p.emoji}</div>
          <div class="tp-info">
            <div class="tp-text">${p.text}</div>
            <div class="tp-meta">
              <span class="tp-stat">❤️ ${fmtNum(p.likes)}</span>
              <span class="tp-stat">💬 ${p.comments}</span>
              <span class="tp-stat">👁 ${fmtNum(p.reach)}</span>
              <span class="tp-stat" style="color:#085041;font-size:9px">${p.type}</span>
            </div>
          </div>
          <div class="tp-bar-wrap">
            <div class="tp-bar"><div class="tp-bar-fill" style="width:${Math.round(p.reach/maxReach*100)}%"></div></div>
            <div style="font-size:9px;color:var(--muted);margin-top:2px;text-align:right">${fmtNum(p.reach)} portée</div>
          </div>
        </div>`).join('')}
    </div>
  </div>

  <div class="dash-section">
    <div class="dash-sec-title">⏰ Meilleurs moments pour poster</div>
    <div class="heatmap-wrap">
      <div style="font-size:11px;color:var(--muted);margin-bottom:4px;">Engagement par heure (moy. sur ${period} jours)</div>
      <div class="heatmap-grid" id="heatmap"></div>
      <div class="hm-labels">
        <span class="hm-label">0h</span><span class="hm-label">6h</span>
        <span class="hm-label">12h</span><span class="hm-label">18h</span><span class="hm-label">23h</span>
      </div>
      <div style="display:flex;gap:4px;align-items:center;margin-top:8px;">
        <span style="font-size:10px;color:var(--muted)">Faible</span>
        ${[.1,.25,.45,.65,.85,1].map(o=>`<div style="width:14px;height:8px;border-radius:2px;background:#1D9E75;opacity:${o}"></div>`).join('')}
        <span style="font-size:10px;color:var(--muted)">Élevé</span>
      </div>
    </div>
  </div>
  <div style="height:80px"></div>`;
}

// ── AUDIENCE ──────────────────────────────────
function renderAudience(period, stats) {
  return `
  <div class="kpi-grid">
    ${[
      {icon:'👥', val:fmtNum(stats.followers.val), label:'Abonnés totaux', delta:stats.followers.delta, up:true},
      {icon:'👁️', val:fmtNum(stats.profileViews.val), label:'Vues profil', delta:stats.profileViews.delta, up:true},
      {icon:'🔗', val:fmtNum(stats.linkClicks.val), label:'Clics lien', delta:stats.linkClicks.delta, up:stats.linkClicks.delta>0},
      {icon:'📈', val:stats.engagement.val+'%', label:'Taux engagement', delta:stats.engagement.delta, up:true},
    ].map(k=>`
      <div class="kpi-card">
        <div class="kpi-icon">${k.icon}</div>
        <div class="kpi-val">${k.val}</div>
        <div class="kpi-label">${k.label}</div>
        <div class="kpi-delta ${k.up?'up':'down'}">${k.up?'↑':'↓'} ${Math.abs(k.delta)}%</div>
      </div>`).join('')}
  </div>

  <div class="chart-wrap">
    <div class="chart-title">Nouveaux abonnés / jour</div>
    <svg class="chart-svg" height="90" id="chart-new-followers"></svg>
  </div>

  <div class="audience-grid">
    <div class="aud-card">
      <div class="aud-title">Sexe</div>
      <div class="aud-pie">
        ${[{l:'♀️ F',pct:58,c:'#993556'},{l:'♂️ H',pct:38,c:'#185FA5'},{l:'✨ +',pct:4,c:'#534AB7'}].map(a=>`
          <div class="aud-row">
            <div class="aud-label">${a.l}</div>
            <div class="aud-bar-bg"><div class="aud-bar-fill" style="width:${a.pct}%;background:${a.c}"></div></div>
            <div class="aud-pct">${a.pct}%</div>
          </div>`).join('')}
      </div>
    </div>
    <div class="aud-card">
      <div class="aud-title">Âge</div>
      <div class="aud-pie">
        ${[{l:'18-24',pct:34,c:'#1D9E75'},{l:'25-34',pct:41,c:'#085041'},{l:'35-44',pct:17,c:'#FAC775'},{l:'45+',pct:8,c:'#D85A30'}].map(a=>`
          <div class="aud-row">
            <div class="aud-label" style="width:36px;font-size:10px">${a.l}</div>
            <div class="aud-bar-bg"><div class="aud-bar-fill" style="width:${a.pct}%;background:${a.c}"></div></div>
            <div class="aud-pct">${a.pct}%</div>
          </div>`).join('')}
      </div>
    </div>
  </div>

  <div class="dash-section" style="margin-top:10px">
    <div class="dash-sec-title">🌍 Top pays</div>
    <div class="chart-wrap">
      ${[
        {flag:'🇷🇼',name:'Rwanda',pct:42},
        {flag:'🇨🇩',name:'Rép. Dém. Congo',pct:18},
        {flag:'🇳🇬',name:'Nigeria',pct:12},
        {flag:'🇸🇳',name:'Sénégal',pct:9},
        {flag:'🇫🇷',name:'France',pct:7},
        {flag:'🇨🇮',name:'Côte d\'Ivoire',pct:5},
        {flag:'🇰🇪',name:'Kenya',pct:4},
        {flag:'🌍',name:'Autres',pct:3},
      ].map(c=>`
        <div class="country-row">
          <div class="country-flag">${c.flag}</div>
          <div class="country-name">${c.name}</div>
          <div style="flex:1;margin:0 10px;"><div class="aud-bar-bg"><div class="aud-bar-fill" style="width:${c.pct}%;background:#1D9E75"></div></div></div>
          <div class="country-pct">${c.pct}%</div>
        </div>`).join('')}
    </div>
  </div>
  <div style="height:80px"></div>`;
}

// ── REVENUS ───────────────────────────────────
function renderRevenu(period, stats) {
  const m = period===7?.25:period===28?1:period===90?3:12;
  const rev = Math.round(124000*m);
  return `
  <div style="background:linear-gradient(135deg,#085041,#1D9E75);border-radius:14px;padding:20px;margin-bottom:14px;text-align:center;">
    <div style="font-size:12px;color:rgba(255,255,255,.75);margin-bottom:4px;">Revenus estimés (${period} jours)</div>
    <div style="font-size:32px;font-weight:500;color:#fff;font-family:'Playfair Display',serif;">${fmtNum(rev)} <span style="font-size:16px;opacity:.8">FCFA</span></div>
    <div style="font-size:11px;color:#9FE1CB;margin-top:4px;">↑ +28.4% vs période précédente</div>
  </div>

  <div class="kpi-grid">
    ${[
      {icon:'🎁', val:fmtNum(Math.round(54000*m)),  label:'Dons live',       delta:+41.2, up:true},
      {icon:'🛍️', val:fmtNum(Math.round(38000*m)),  label:'Boutique Bao',    delta:+22.8, up:true},
      {icon:'⭐', val:fmtNum(Math.round(22000*m)),  label:'Abonnés Premium', delta:+15.3, up:true},
      {icon:'📢', val:fmtNum(Math.round(10000*m)),  label:'Partenariats',    delta:-5.1,  up:false},
    ].map(k=>`
      <div class="kpi-card">
        <div class="kpi-icon">${k.icon}</div>
        <div class="kpi-val">${k.val}</div>
        <div class="kpi-label">${k.label}</div>
        <div class="kpi-delta ${k.up?'up':'down'}">${k.up?'↑':'↓'} ${Math.abs(k.delta)}%</div>
      </div>`).join('')}
  </div>

  <div class="chart-wrap">
    <div class="chart-title">Évolution des revenus</div>
    <svg class="chart-svg" height="100" id="chart-revenue"></svg>
  </div>

  <div class="dash-section">
    <div class="dash-sec-title">🚀 Augmente tes revenus</div>
    <div class="tip-card">
      <div class="tip-icon">⭐</div>
      <div class="tip-text"><div class="tip-title">Active le mode Premium</div>Offre du contenu exclusif à tes abonnés payants — Lives privés, posts exclusifs, accès anticipé.</div>
    </div>
    <div class="tip-card" style="background:linear-gradient(135deg,#854F0B,#FAC775)">
      <div class="tip-icon">🛍️</div>
      <div class="tip-text"><div class="tip-title">Ouvre ta Boutique Bao</div>Vends tes créations directement sur ton profil — prints, presets photo, services.</div>
    </div>
  </div>
  <button class="dash-export-btn" onclick="exportStats()">📥 Exporter le rapport financier</button>
  <div style="height:80px"></div>`;
}

// ── SVG CHARTS ────────────────────────────────
function drawCharts(tab, period) {
  if(tab==='vue-ensemble') {
    const days = Math.min(period, 28);
    drawLineChart('chart-followers',
      [genData(days,160,40,1), genData(days,18,8,1)],
      ['#1D9E75','#FAC775'], days);
    drawAreaChart('chart-reach',
      [genData(days,620,180,1)],
      ['#185FA5'], days);
  }
  if(tab==='contenu') {
    drawHeatmap();
  }
  if(tab==='audience') {
    const days = Math.min(period,28);
    drawBarChart('chart-new-followers', genData(days,28,15,1), '#1D9E75', days);
  }
  if(tab==='revenus') {
    const days = Math.min(period,28);
    drawAreaChart('chart-revenue',[genData(days,4400,1200,1)],['#FAC775'],days);
  }
}

function drawLineChart(id, datasets, colors, days) {
  const el = document.getElementById(id);
  if(!el) return;
  const W = el.parentElement.offsetWidth - 28;
  const H = 110;
  const pad = {t:10,r:8,b:20,l:30};
  const w = W - pad.l - pad.r;
  const h = H - pad.t - pad.b;
  const allVals = datasets.flat();
  const minV = 0, maxV = Math.max(...allVals)*1.15;

  const x = i => pad.l + (i/(days-1))*w;
  const y = v => pad.t + h - ((v-minV)/(maxV-minV||1))*h;

  let svg = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">`;
  // Grid
  [0,.25,.5,.75,1].forEach(f=>{
    const yy = pad.t + h*(1-f);
    const val = Math.round(minV + (maxV-minV)*f);
    svg += `<line x1="${pad.l}" y1="${yy}" x2="${W-pad.r}" y2="${yy}" class="chart-grid"/>`;
    svg += `<text x="${pad.l-4}" y="${yy+3}" class="chart-label" text-anchor="end">${fmtNum(val)}</text>`;
  });
  datasets.forEach((data,di) => {
    const pts = data.map((v,i)=>`${x(i)},${y(v)}`).join(' ');
    const firstPt = `${x(0)},${y(data[0])}`;
    const lastPt = `${x(data.length-1)},${y(data[data.length-1])}`;
    svg += `<polyline points="${pts}" class="chart-line" stroke="${colors[di]}"/>`;
    // Area fill
    svg += `<polygon points="${firstPt} ${pts} ${lastPt} ${x(data.length-1)},${pad.t+h} ${x(0)},${pad.t+h}" fill="${colors[di]}" fill-opacity=".1"/>`;
    data.forEach((v,i) => {
      if(i===0||i===data.length-1||i===Math.floor(data.length/2))
        svg += `<circle cx="${x(i)}" cy="${y(v)}" r="3" fill="${colors[di]}" stroke="var(--card)" stroke-width="2"/>`;
    });
  });
  svg += '</svg>';
  el.outerHTML = svg;
}

function drawAreaChart(id, datasets, colors, days) {
  drawLineChart(id, datasets, colors, days);
}

function drawBarChart(id, data, color, days) {
  const el = document.getElementById(id);
  if(!el) return;
  const W = el.parentElement.offsetWidth - 28;
  const H = 90;
  const pad = {t:8,r:8,b:18,l:28};
  const w = W - pad.l - pad.r;
  const h = H - pad.t - pad.b;
  const maxV = Math.max(...data)*1.15||1;
  const barW = Math.max(2, w/days - 2);

  let svg = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">`;
  [0,.5,1].forEach(f=>{
    const yy = pad.t + h*(1-f);
    svg += `<line x1="${pad.l}" y1="${yy}" x2="${W-pad.r}" y2="${yy}" class="chart-grid"/>`;
    svg += `<text x="${pad.l-4}" y="${yy+3}" class="chart-label" text-anchor="end">${fmtNum(Math.round(maxV*f))}</text>`;
  });
  data.forEach((v,i) => {
    const bh = (v/maxV)*h;
    const bx = pad.l + (i/days)*w;
    const by = pad.t + h - bh;
    svg += `<rect x="${bx}" y="${by}" width="${barW}" height="${bh}" rx="2" fill="${color}" opacity="${.5+.5*(v/maxV)}"/>`;
  });
  svg += '</svg>';
  el.outerHTML = svg;
}

function drawHeatmap() {
  const el = document.getElementById('heatmap');
  if(!el) return;
  const hours = Array.from({length:24}, (_,h) => {
    // Peak at 7-9am and 18-21pm
    const morning = Math.exp(-((h-8)**2)/4);
    const evening = Math.exp(-((h-19)**2)/4);
    return Math.max(0.05, morning*.6 + evening + Math.random()*.15);
  });
  const maxH = Math.max(...hours);
  el.innerHTML = hours.map((v,h) => {
    const opacity = 0.1 + (v/maxH)*0.9;
    const isHot = v/maxH > 0.7;
    return `<div class="hm-cell" style="background:#1D9E75;opacity:${opacity.toFixed(2)};${isHot?'box-shadow:0 0 4px rgba(29,158,117,.5)':''}" title="${h}h — ${isHot?'🔥 Très actif':'Peu actif'}"></div>`;
  }).join('');
}

function exportStats() {
  const btn = event.target;
  const orig = btn.innerHTML;
  btn.innerHTML = '⏳ Génération…';
  btn.disabled = true;
  setTimeout(()=>{
    btn.innerHTML = '✅ Rapport prêt (simulé)';
    setTimeout(()=>{ btn.innerHTML = orig; btn.disabled = false; }, 2000);
  }, 1500);
}

// ── Search index ─────────────────────────────
const SEARCH_DB = {
  personnes: PEOPLE.map(p => ({
    type:'personne', icon:p.init, color:p.color,
    name:p.name, sub:`${p.handle} · ${p.followers} abonnés`,
    handle:p.handle, online:p.online, following:p.following,
    keywords: [p.name.toLowerCase(), p.handle.toLowerCase()]
  })),
  posts: [
    {type:'post',emoji:'🌅',bg:'#E1F5EE',text:'Le coucher de soleil sur la colline Rebero 😍 #KigaliVibe',sub:'Amina Diallo · 1.2k j\'aime',keywords:['soleil','kigali','rebero','kigalivibe']},
    {type:'post',emoji:'🍛',bg:'#FAEEDA',text:'Mon jollof rice est officiellement le meilleur du continent 🤌',sub:'Kweku Mensah · 874 j\'aime',keywords:['jollof','rice','food','cuisine','afrikafood']},
    {type:'post',emoji:'🌍',bg:'#E1F5EE',text:'Life Bao connecte les âmes africaines à travers le monde 💚',sub:'Fatou Sow · 632 j\'aime',keywords:['lifebao','afrique','africain','bao']},
    {type:'post',emoji:'📸',bg:'#EEEDFE',text:'Nouvelle série photo : Visages de Kigali 🎞️ #AfrikaArt',sub:'Keza Mutoni · 512 j\'aime',keywords:['photo','kigali','afrikaart','portrait','serie']},
    {type:'post',emoji:'🎵',bg:'#E6F1FB',text:'Session beatmaking en live ce soir 🎧 Rejoignez-moi !',sub:'Kweku Mensah · 389 j\'aime',keywords:['musique','beatmaking','live','session']},
  ],
  tags: [
    {type:'tag',name:'#KigaliVibe',sub:'24.3k posts · 🔥 Tendance',heat:'↑+42%',keywords:['kigali','vibe','kigalivibe']},
    {type:'tag',name:'#AfrikaFood',sub:'18.1k posts · 🍛 Food',heat:'↑+28%',keywords:['food','afrique','cuisine','afrikaFood']},
    {type:'tag',name:'#LifeBao',sub:'51.7k posts · ⭐ Top',heat:'↑+15%',keywords:['lifebao','bao','reseau']},
    {type:'tag',name:'#SunsetAfrica',sub:'9.8k posts',heat:'↑+67%',keywords:['sunset','soleil','afrique']},
    {type:'tag',name:'#AfrikaArt',sub:'14.2k posts · 🎨 Art',heat:'↑+33%',keywords:['art','afrikaart','creation','afrique']},
    {type:'tag',name:'#BaoFam',sub:'7.4k posts · 👨‍👩‍👧‍👦 Communauté',heat:'↑+19%',keywords:['bao','famille','communaute','baofam']},
    {type:'tag',name:'#RwandaBeauty',sub:'4.2k posts',heat:'↑+51%',keywords:['rwanda','beaute','paysage']},
    {type:'tag',name:'#KigaliNights',sub:'3.8k posts',heat:'↑+38%',keywords:['kigali','nuit','soiree']},
  ],
  groupes: [
    {type:'groupe',emoji:'📸',bg:'linear-gradient(135deg,#085041,#1D9E75)',name:'Photographes de Kigali',sub:'128 membres · 🔒 Privé',keywords:['photo','kigali','photographe']},
    {type:'groupe',emoji:'🍛',bg:'linear-gradient(135deg,#854F0B,#D85A30)',name:'Foodies de Dakar',sub:'2.4k membres · 🌐 Public',keywords:['food','dakar','cuisine','foodies']},
    {type:'groupe',emoji:'🎵',bg:'linear-gradient(135deg,#185FA5,#534AB7)',name:'African Creators Hub',sub:'5.1k membres · 🌐 Public',keywords:['createurs','musique','hub','africain']},
    {type:'groupe',emoji:'💼',bg:'linear-gradient(135deg,#2C2C2A,#5F5E5A)',name:'Entrepreneurs Afrique',sub:'892 membres · 🔒 Privé',keywords:['business','entrepreneur','afrique']},
  ],
  pages: [
    {type:'page',emoji:'📸',bg:'linear-gradient(135deg,#085041,#1D9E75)',name:'Keza Photo Studio',sub:'342 abonnés · Photographie',keywords:['photo','studio','keza','photographie']},
    {type:'page',emoji:'🍛',bg:'linear-gradient(135deg,#854F0B,#FAC775)',name:'AfrikaFood Blog',sub:'12.4k abonnés · Food',keywords:['food','blog','afrique','cuisine']},
    {type:'page',emoji:'👗',bg:'linear-gradient(135deg,#993556,#D85A30)',name:'Kigali Fashion Week',sub:'8.2k abonnés · Mode',keywords:['fashion','mode','kigali','semaine']},
  ],
  lives: [
    {type:'live',emoji:'🌅',bg:'linear-gradient(135deg,#085041,#1D9E75)',name:'Séance photo sunset 📸',sub:'Amina Diallo · 👁 1 247',keywords:['photo','sunset','soleil','direct']},
    {type:'live',emoji:'🍛',bg:'linear-gradient(135deg,#854F0B,#D85A30)',name:'Cuisine africaine 🍽️',sub:'Fatou Sow · 👁 538',keywords:['cuisine','food','recette','direct']},
    {type:'live',emoji:'🎵',bg:'linear-gradient(135deg,#185FA5,#534AB7)',name:'Session beatmaking 🎧',sub:'Kweku Mensah · 👁 324',keywords:['musique','beat','session','direct']},
  ],
};

let searchQuery = '';
let searchFilter = 'tout';
let searchHistory = JSON.parse(localStorage.getItem('lifebao_search_history')||'[]');
let searchTimer = null;
let voiceActive = false;

// ── Open / Close ─────────────────────────────
function openSearch() {
  const overlay = document.getElementById('search-overlay');
  overlay.classList.add('open');
  setTimeout(()=>{
    const inp = document.getElementById('global-search-input');
    if(inp) inp.focus();
  }, 150);
  renderSearchDefault();
}

function closeSearch() {
  document.getElementById('search-overlay').classList.remove('open');
  clearGlobalSearch();
}

function clearGlobalSearch() {
  const inp = document.getElementById('global-search-input');
  if(inp) inp.value='';
  searchQuery='';
  document.getElementById('sr-clear').style.display='none';
  renderSearchDefault();
}

function handleSearchKey(e) {
  if(e.key==='Escape') closeSearch();
  if(e.key==='Enter' && searchQuery.trim()) {
    saveSearchHistory(searchQuery.trim());
    executeSearch(searchQuery.trim());
  }
}

// ── Render default state (history + trending) ─
function renderSearchDefault() {
  const body = document.getElementById('sr-body');
  let html = '';

  // Search history
  if(searchHistory.length > 0) {
    html += `<div class="sr-section">
      <div class="sr-sec-title">🕐 Recherches récentes <span class="sr-sec-all" onclick="clearHistory()">Effacer tout</span></div>
      ${searchHistory.slice(0,6).map((q,i)=>`
        <div class="search-history-item" onclick="clickHistory('${q.replace(/'/g,'\\\'') }')">
          <span class="shi-icon">🕐</span>
          <span class="shi-text">${q}</span>
          <button class="shi-remove" onclick="event.stopPropagation();removeHistory(${i})">✕</button>
        </div>`).join('')}
    </div>`;
  }

  // Trending tags
  html += `<div class="search-trending">
    <div class="sr-sec-title">🔥 Tendances</div>
    ${SEARCH_DB.tags.map(t=>`
      <span class="st-tag" onclick="clickTag('${t.name}')">
        ${t.name} <span class="st-heat">${t.heat}</span>
      </span>`).join('')}
  </div>`;

  // Suggested people
  html += `<div class="sr-section">
    <div class="sr-sec-title">👥 Personnes suggérées</div>
    ${SEARCH_DB.personnes.slice(0,3).map((p,i)=>renderPersonRow(p, '', i)).join('')}
  </div>`;

  html += '<div style="height:80px"></div>';
  body.innerHTML = html;
}

// ── Live search ───────────────────────────────
function handleGlobalSearch(val) {
  searchQuery = val.trim();
  const clearBtn = document.getElementById('sr-clear');
  if(clearBtn) clearBtn.style.display = val ? 'block' : 'none';

  clearTimeout(searchTimer);
  if(!val.trim()) { renderSearchDefault(); return; }

  // Show loading
  document.getElementById('sr-body').innerHTML = `<div class="sr-loading"><div class="sr-dot"></div><div class="sr-dot"></div><div class="sr-dot"></div></div>`;

  searchTimer = setTimeout(()=>executeSearch(val.trim()), 280);
}

function executeSearch(q) {
  const body = document.getElementById('sr-body');
  const ql = q.toLowerCase();
  const filter = searchFilter;

  const score = (item) => {
    let s = 0;
    item.keywords.forEach(kw => {
      if(kw.includes(ql)) s += kw.startsWith(ql) ? 3 : 1;
    });
    if((item.name||'').toLowerCase().includes(ql)) s += 5;
    if((item.text||'').toLowerCase().includes(ql)) s += 2;
    return s;
  };

  const search = (arr) => arr.map(item=>({...item,score:score(item)})).filter(i=>i.score>0).sort((a,b)=>b.score-a.score);

  const results = {
    personnes: search(SEARCH_DB.personnes),
    posts:     search(SEARCH_DB.posts),
    tags:      search(SEARCH_DB.tags),
    groupes:   search(SEARCH_DB.groupes),
    pages:     search(SEARCH_DB.pages),
    lives:     search(SEARCH_DB.lives),
  };

  const total = Object.values(results).reduce((a,b)=>a+b.length,0);
  let html = '';

  if(total === 0) {
    html = `<div class="sr-empty">
      <div class="sr-empty-icon">🔍</div>
      <div style="font-size:14px;font-weight:500;color:var(--text)">Aucun résultat pour « ${q} »</div>
      <div style="font-size:12px;color:var(--muted);margin-top:4px">Essaie avec d'autres mots-clés</div>
    </div>`;
    body.innerHTML = html;
    return;
  }

  const shouldShow = (type) => filter==='tout' || filter===type;
  const hl = (text) => text.replace(new RegExp(`(${ql})`, 'gi'), '<span class="match">$1</span>');

  if(shouldShow('personnes') && results.personnes.length) {
    html += `<div class="sr-section">
      <div class="sr-sec-title">👥 Personnes <span class="sr-sec-all">Voir tout</span></div>
      ${results.personnes.slice(0,filter==='tout'?3:8).map((p,i)=>renderPersonRow(p,ql,i)).join('')}
    </div>`;
  }

  if(shouldShow('tags') && results.tags.length) {
    html += `<div class="sr-section">
      <div class="sr-sec-title"># Tags <span class="sr-sec-all">Voir tout</span></div>
      ${results.tags.slice(0,filter==='tout'?3:6).map(t=>`
        <div class="sr-row" onclick="clickTag('${t.name}')">
          <div class="sr-row-icon tag">#️⃣</div>
          <div class="sr-row-body">
            <div class="sr-row-name">${hl(t.name)}</div>
            <div class="sr-row-sub">${t.sub}</div>
          </div>
          <div class="sr-row-right" style="color:var(--coral);font-weight:600">${t.heat}</div>
        </div>`).join('')}
    </div>`;
  }

  if(shouldShow('posts') && results.posts.length) {
    html += `<div class="sr-section">
      <div class="sr-sec-title">📝 Posts <span class="sr-sec-all">Voir tout</span></div>
      ${results.posts.slice(0,filter==='tout'?2:5).map(p=>`
        <div class="sr-row">
          <div class="sr-row-icon post" style="background:${p.bg}">${p.emoji}</div>
          <div class="sr-row-body">
            <div class="sr-row-name" style="font-weight:400">${hl(p.text)}</div>
            <div class="sr-row-sub">${p.sub}</div>
          </div>
        </div>`).join('')}
    </div>`;
  }

  if(shouldShow('groupes') && results.groupes.length) {
    html += `<div class="sr-section">
      <div class="sr-sec-title">🏘️ Groupes</div>
      ${results.groupes.slice(0,filter==='tout'?2:5).map(g=>`
        <div class="sr-row" onclick="goScreen('communaute')">
          <div class="sr-row-icon group" style="background:${g.bg}">${g.emoji}</div>
          <div class="sr-row-body">
            <div class="sr-row-name">${hl(g.name)}</div>
            <div class="sr-row-sub">${g.sub}</div>
          </div>
          <button class="sr-row-action" onclick="event.stopPropagation();this.textContent='✓ Rejoint';this.className='sr-row-action following'">Rejoindre</button>
        </div>`).join('')}
    </div>`;
  }

  if(shouldShow('pages') && results.pages.length) {
    html += `<div class="sr-section">
      <div class="sr-sec-title">📄 Pages</div>
      ${results.pages.slice(0,filter==='tout'?2:5).map(p=>`
        <div class="sr-row" onclick="goScreen('communaute')">
          <div class="sr-row-icon page" style="background:${p.bg};border-radius:10px">${p.emoji}</div>
          <div class="sr-row-body">
            <div class="sr-row-name">${hl(p.name)}</div>
            <div class="sr-row-sub">${p.sub}</div>
          </div>
          <button class="sr-row-action" onclick="event.stopPropagation();this.textContent='✓ Abonné';this.className='sr-row-action following'">S'abonner</button>
        </div>`).join('')}
    </div>`;
  }

  if(shouldShow('lives') && results.lives.length) {
    html += `<div class="sr-section">
      <div class="sr-sec-title">🔴 Lives en cours</div>
      ${results.lives.slice(0,filter==='tout'?2:5).map(l=>`
        <div class="sr-row" onclick="closeSearch();goScreen('live')">
          <div class="sr-row-icon" style="background:${l.bg};border-radius:10px">${l.emoji}</div>
          <div class="sr-row-body">
            <div class="sr-row-name">${hl(l.name)}</div>
            <div class="sr-row-sub">${l.sub}</div>
          </div>
          <div style="background:var(--coral);color:#fff;font-size:9px;font-weight:600;border-radius:20px;padding:2px 7px;display:flex;align-items:center;gap:3px;flex-shrink:0"><span style="width:5px;height:5px;border-radius:50%;background:#fff;animation:blink 1s infinite;display:inline-block"></span>DIRECT</div>
        </div>`).join('')}
    </div>`;
  }

  html += '<div style="height:80px"></div>';
  body.innerHTML = html;
}

// ── Person row helper ─────────────────────────
function renderPersonRow(p, ql='', idx=0) {
  const hl = (text) => ql ? text.replace(new RegExp(`(${ql})`, 'gi'), '<span class="match">$1</span>') : text;
  return `<div class="sr-row" onclick="closeSearch()">
    <div class="sr-row-icon" style="background:${p.color}">${p.init}${p.online?'<span style="position:absolute;bottom:0;right:0;width:9px;height:9px;border-radius:50%;background:#1D9E75;border:2px solid var(--card)"></span>':''}</div>
    <div class="sr-row-body">
      <div class="sr-row-name">${hl(p.name)}</div>
      <div class="sr-row-sub">${hl(p.sub||'')}</div>
    </div>
    <button class="sr-row-action${p.following?' following':''}" onclick="event.stopPropagation();toggleSearchFollow(this,${idx})">${p.following?'Abonné·e':"S'abonner"}</button>
  </div>`;
}

function toggleSearchFollow(btn, idx) {
  SEARCH_DB.personnes[idx].following = !SEARCH_DB.personnes[idx].following;
  btn.classList.toggle('following');
  btn.textContent = SEARCH_DB.personnes[idx].following ? 'Abonné·e' : "S'abonner";
  // Sync with PEOPLE array
  if(PEOPLE[idx]) PEOPLE[idx].following = SEARCH_DB.personnes[idx].following;
}

// ── Filter chips ──────────────────────────────
function filterSearch(el, filter) {
  searchFilter = filter;
  document.querySelectorAll('.sf-chip').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');
  if(searchQuery) executeSearch(searchQuery);
  else renderSearchDefault();
}

// ── History ───────────────────────────────────
function saveSearchHistory(q) {
  searchHistory = [q, ...searchHistory.filter(h=>h!==q)].slice(0,10);
  localStorage.setItem('lifebao_search_history', JSON.stringify(searchHistory));
}

function clickHistory(q) {
  const inp = document.getElementById('global-search-input');
  if(inp) { inp.value=q; }
  searchQuery = q;
  document.getElementById('sr-clear').style.display='block';
  executeSearch(q);
}

function clickTag(tag) {
  const q = tag.replace('#','');
  const inp = document.getElementById('global-search-input');
  if(inp) inp.value = tag;
  searchQuery = q;
  document.getElementById('sr-clear').style.display='block';
  saveSearchHistory(tag);
  executeSearch(q);
}

function removeHistory(idx) {
  searchHistory.splice(idx,1);
  localStorage.setItem('lifebao_search_history', JSON.stringify(searchHistory));
  renderSearchDefault();
}

function clearHistory() {
  searchHistory = [];
  localStorage.removeItem('lifebao_search_history');
  renderSearchDefault();
}

// ── Voice search (simulated) ─────────────────
function toggleVoice() {
  const btn = document.getElementById('voice-btn');
  voiceActive = !voiceActive;
  btn.classList.toggle('listening', voiceActive);
  if(voiceActive) {
    const inp = document.getElementById('global-search-input');
    if(inp) inp.placeholder = '🎙️ Écoute en cours…';
    // Simulate voice recognition
    const voiceTerms = ['#KigaliVibe','Amina Diallo','AfrikaFood','Photographes de Kigali'];
    setTimeout(()=>{
      voiceActive = false;
      btn.classList.remove('listening');
      if(inp) {
        inp.placeholder = 'Rechercher sur Life Bao…';
        const term = voiceTerms[Math.floor(Math.random()*voiceTerms.length)];
        inp.value = term;
        searchQuery = term;
        document.getElementById('sr-clear').style.display='block';
        executeSearch(term);
      }
    }, 1800);
  } else {
    const inp = document.getElementById('global-search-input');
    if(inp) inp.placeholder = 'Rechercher sur Life Bao…';
  }
}

// ── Top menu ─────────────────────────────────
function openTopMenu(btn) {
  const menu = document.getElementById('top-menu');
  const overlay = document.getElementById('top-menu-overlay');
  if(!menu) return;
  const isOpen = menu.style.display === 'block';
  if(isOpen) { closeTopMenu(); return; }
  menu.style.display = 'block';
  if(overlay) overlay.style.display = 'block';
  // Update dark mode label
  const isDark = document.documentElement.getAttribute('data-theme')==='dark';
  const icon = document.getElementById('tm-dark-icon');
  const lbl = document.getElementById('tm-dark-label');
  if(icon) icon.textContent = isDark ? '☀️' : '🌙';
  if(lbl) lbl.textContent = isDark ? 'Mode clair' : 'Mode sombre';
  // Update avatar/name from session
  if(currentUser) {
    const av = document.getElementById('tm-avatar');
    const nm = document.getElementById('tm-name');
    if(av) av.textContent = (currentUser.firstname?.[0]||'K')+(currentUser.lastname?.[0]||'M');
    if(nm) nm.textContent = (currentUser.firstname||'Keza')+' '+(currentUser.lastname||'Mutoni');
  }
}
function closeTopMenu() {
  const menu = document.getElementById('top-menu');
  const overlay = document.getElementById('top-menu-overlay');
  if(menu) menu.style.display = 'none';
  if(overlay) overlay.style.display = 'none';
}

// Fast touch response
document.addEventListener('touchstart', function(){}, {passive:true});

renderFil();
renderNotifs();
renderConvos();
renderProfGrid();
renderExpContent('tout');
renderCommunaute();
renderLiveList();
initAuth();
